# Jenkins GitHub Webhook Validation

- Generated at: `2026-04-12T22:18:46Z`
- Jenkins URL: `http://localhost:8085`
- CI job: `securerag-hub-ci`
- Git remote: `https://github.com/YassinoMed/MasterPFE.git`

| Component | Status | Detail |
|---|---:|---|
| Jenkins login | FAIL | HTTP 000 |
