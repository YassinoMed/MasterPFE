# Supply Chain Mandatory Evidence Gate

- Generated at: `2026-09-22T17:05:58Z`
- REQUIRE_SUPPLY_CHAIN_EVIDENCE: `true`
- Expected services: `5`
- Services: `auth-users chatbot-manager conversation-service audit-security-service portal-web`

| Required evidence | Status | Detail |
|---|---:|---|
| Trivy image scan summary | OK | PASS=0, WARN=5, accepted=5/5, sha256=25ab98d8f38e320bb10571ff46fbd0fe815b71ced5eb071f5afaf2ef2a8d253c |
| Cosign sign summary | FAIL | `artifacts/release/sign-summary.txt`: PASS=0/5, FAIL=0, SKIP=5 |
| Cosign verify summary | OK | PASS=5/5, sha256=ab474f3adad4f90664e26145dd35d14be39886505436e40ee9ba150739972019 |
| Digest promotion summary | OK | PASS=5/5, sha256=b11107d7854866586248839f5f8de73202c69e0a2b184451df0e5e1d5a918da8 |
| Digest promotion record | OK | records=5/5, sha256=b97cc042fecf3cd95fd1b9b1802abe667a61ab92c0227b45ab75492e228b8dfc |
| SBOM generation summary | OK | PASS=5/5, sha256=8efd87f539be8779b10b694e3263023797896241b6547824eff822519a164fcc |
| Cosign SBOM attestation summary | FAIL | `artifacts/release/attest-summary.txt` missing or empty |
| SBOM index | OK | records=5/5, sha256=4d44649f016d3761188ad94bfebac70ea3f30aa867010558f15185c24cff054c |
| Release attestation | FAIL | `artifacts/release/release-attestation.json` is present but not COMPLETE_PROVEN |

## Global status

Statut global: `DÉPENDANT_DE_L_ENVIRONNEMENT`

Required supply-chain evidence is absent or incomplete in the current environment. Run the full release chain with Docker, registry access, Trivy, Syft, Cosign and valid signing keys.
