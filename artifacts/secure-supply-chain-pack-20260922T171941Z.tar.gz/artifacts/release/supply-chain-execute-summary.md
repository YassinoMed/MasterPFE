# Supply Chain Execute Summary

- Generated at: `2026-09-22T17:18:42Z`
- Mode: `execute`
- Registry: `localhost:5001`
- Image prefix: `securerag-hub`
- Source tag: `dev`
- Target tag: `release-local`

## Preflight

- OK: `localhost:5001/securerag-hub-auth-users:dev`
- OK: `localhost:5001/securerag-hub-chatbot-manager:dev`
- OK: `localhost:5001/securerag-hub-conversation-service:dev`
- OK: `localhost:5001/securerag-hub-audit-security-service:dev`
- OK: `localhost:5001/securerag-hub-portal-web:dev`
