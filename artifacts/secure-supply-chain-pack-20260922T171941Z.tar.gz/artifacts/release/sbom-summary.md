# Syft SBOM Summary - SecureRAG Hub

- Generated at UTC: `2026-09-22T17:19:01Z`
- Syft version: `Application: syft`
- Format: `cyclonedx-json`

| Service | Image | Status | Source | SBOM | Components | SHA256 | Detail |
|---|---|---:|---|---|---:|---|---|
| `auth-users` | `localhost:5001/securerag-hub-auth-users:release-local` | `PASS` | `docker` | `artifacts/sbom/auth-users-sbom.cdx.json` | 127 | `02a5be56f68e8553c906fcaf1a8dabcf3cb75701d8a63fcb728e7a4a6856a5ba` | CycloneDX JSON valid |
| `chatbot-manager` | `localhost:5001/securerag-hub-chatbot-manager:release-local` | `PASS` | `docker` | `artifacts/sbom/chatbot-manager-sbom.cdx.json` | 127 | `21ce01ccd9fbbc14b08bfac73d1578e4c904a106ca2d821ffd6020574dc4a445` | CycloneDX JSON valid |
| `conversation-service` | `localhost:5001/securerag-hub-conversation-service:release-local` | `PASS` | `docker` | `artifacts/sbom/conversation-service-sbom.cdx.json` | 127 | `7185070e3fe2ef6836073f01e52359285ee35fea6fbfcf4c2fe9778c1415ab86` | CycloneDX JSON valid |
| `audit-security-service` | `localhost:5001/securerag-hub-audit-security-service:release-local` | `PASS` | `docker` | `artifacts/sbom/audit-security-service-sbom.cdx.json` | 127 | `dc5c13f30b57f9eb6383c24d40d3dc8cf59a58df90d7774b0b6ff8c8bd9f6d0a` | CycloneDX JSON valid |
| `portal-web` | `localhost:5001/securerag-hub-portal-web:release-local` | `PASS` | `docker` | `artifacts/sbom/portal-web-sbom.cdx.json` | 127 | `7298917e33d36e955f5416247fb4734df8fa06f4f31e56627bb5b4cf0c86a35f` | CycloneDX JSON valid |

## Result

- PASS: `5`
- FAIL: `0`
- SKIP: `0`
- Text index: `artifacts/sbom/sbom-index.txt`
- JSON index: `artifacts/sbom/sbom-index.json`
