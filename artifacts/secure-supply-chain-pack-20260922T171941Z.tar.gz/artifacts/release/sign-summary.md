# Cosign Sign Summary - SecureRAG Hub

- Generated at UTC: `2026-09-22T17:18:52Z`
- Cosign version: `  ______   ______        _______. __    _______ .__   __.`
- Mode: `keyless`

| Service | Image | Status | Digest | Mode | Log | Detail |
|---|---|---:|---|---|---|---|
| `auth-users` | `localhost:5001/securerag-hub-auth-users@sha256:0d7795be3c8c678f3616779b1365d5ae160efce38b6a2e03c8b6fba3bf74ec93` | `SKIP` | `sha256:0d7795be3c8c678f3616779b1365d5ae160efce38b6a2e03c8b6fba3bf74ec93` | `keyless` | `artifacts/release/auth-users-sign.log` | cosign sign unavailable (dev fallback) |
| `chatbot-manager` | `localhost:5001/securerag-hub-chatbot-manager@sha256:7d52f77d49fe1b3f458cb4c06ac9f3568c2f48c3a4f27dff56a39d59a11195eb` | `SKIP` | `sha256:7d52f77d49fe1b3f458cb4c06ac9f3568c2f48c3a4f27dff56a39d59a11195eb` | `keyless` | `artifacts/release/chatbot-manager-sign.log` | cosign sign unavailable (dev fallback) |
| `conversation-service` | `localhost:5001/securerag-hub-conversation-service@sha256:68e3d1f29ed008be81171d5a9f7711da5b030ad2e26846828905def992fe5b6c` | `SKIP` | `sha256:68e3d1f29ed008be81171d5a9f7711da5b030ad2e26846828905def992fe5b6c` | `keyless` | `artifacts/release/conversation-service-sign.log` | cosign sign unavailable (dev fallback) |
| `audit-security-service` | `localhost:5001/securerag-hub-audit-security-service@sha256:f681d9c8f698b01be192a2471cc5230652ccc0f2ce8fcbe86433e468ede0a58b` | `SKIP` | `sha256:f681d9c8f698b01be192a2471cc5230652ccc0f2ce8fcbe86433e468ede0a58b` | `keyless` | `artifacts/release/audit-security-service-sign.log` | cosign sign unavailable (dev fallback) |
| `portal-web` | `localhost:5001/securerag-hub-portal-web@sha256:190cc8a29e316c9693ce0a4965379d4c3ee5a878f264deaf028639628ba29b06` | `SKIP` | `sha256:190cc8a29e316c9693ce0a4965379d4c3ee5a878f264deaf028639628ba29b06` | `keyless` | `artifacts/release/portal-web-sign.log` | cosign sign unavailable (dev fallback) |

## Result

- PASS: `0`
- FAIL: `0`
- SKIP: `5`
- JSON index: `artifacts/release/sign-index.json`
