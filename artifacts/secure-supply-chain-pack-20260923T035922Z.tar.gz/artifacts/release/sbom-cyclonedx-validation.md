# SBOM CycloneDX Validation - SecureRAG Hub

- Generated at UTC: `2026-09-22T17:04:17Z`
- Status: `TERMINÉ`
- SBOM directory: `artifacts/sbom`

## Detail

All indexed SBOMs are valid CycloneDX JSON files.
