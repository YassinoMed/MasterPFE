# Supply Chain Mandatory Evidence Gate

- Generated at: `2026-09-22T17:33:04Z`
- REQUIRE_SUPPLY_CHAIN_EVIDENCE: `true`
- Expected services: `5`
- Services: `auth-users chatbot-manager conversation-service audit-security-service portal-web`

| Required evidence | Status | Detail |
|---|---:|---|
| Trivy image scan summary | OK | PASS=0, WARN=5, accepted=5/5, sha256=26e7a4853bc5bde878c019250ac1394e3ce867e39a9eac905ab6e2bc100ea64d |
| Cosign sign summary | OK | PASS=5/5, sha256=7caf3fba7b8291b0fdc28ae2c90fa0eced6e64ea9332d262afb4f5d50ac24461 |
| Cosign verify summary | OK | PASS=5/5, sha256=6aba125a0185e1caebfa6f3a0ec401a90b5f7e03a26a51ff626d95d147bca04f |
| Digest promotion summary | OK | PASS=5/5, sha256=abb01fe3ea53a051fd8dde90389c9cf5b8fd28ed09a409d2377c53436d9b1def |
| Digest promotion record | OK | records=5/5, sha256=af6bbb29f18fabaafad028ae2585da55d740c0e7dd14f2e82c1e18c3c2abda17 |
| SBOM generation summary | OK | PASS=5/5, sha256=e5b465661321294d1c03a756dd3647a5c09f76c959f8cddc5f2b35bc19f1a022 |
| Cosign SBOM attestation summary | OK | PASS=5/5, sha256=4a5df499fdbc2b3dbd11883442b87fe6851a1c507b7045b81dab10b97bf24809 |
| SBOM index | OK | records=5/5, sha256=9422bee970707106d27ec124aa0dcda5006ec19ee8fc45c0476315e50ef276f6 |
| Release attestation | OK | status=COMPLETE_PROVEN, sha256=7eea8edade9dd72a15609cd473df71a7851c5e725d998be8502b6273ed9cbc7c |

## Global status

Statut global: `TERMINÉ`

All mandatory supply-chain release gates are proven for the expected official services.
