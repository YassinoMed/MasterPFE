# SecureRAG Hub Evidence & Support Pack

- Generated at UTC: `2026-07-18T13:31:42Z`
- Support Pack ID: `securerag-hub-support-pack-20260718T133110Z`
- Git Commit: `d40fb6193d0ed5431c3cab7cf35860344f2cdf7f`
- Cluster Context: `kind-securerag-dev`

## Contents

- `postdeploy/`: Reports from smoke tests, k8s hardening check, and runtime checks.
- `security-artifacts/`: Trivy, Semgrep, and Gitleaks reports if generated.
- `sbom/`: CycloneDX SBOM files.
- `release/`: Release attestations and promoted digest records.
- `config/`: Pipeline files, Makefiles, and security scanning configurations.
- `k8s-runtime/`: Live cluster configurations, pods list, events, and Kyverno policy reports.
