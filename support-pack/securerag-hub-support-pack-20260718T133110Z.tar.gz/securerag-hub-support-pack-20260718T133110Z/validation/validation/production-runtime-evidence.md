# Production Runtime Evidence - SecureRAG Hub

- Generated at UTC: `2026-07-18T13:21:17Z`
- Namespace: `securerag-hub`
- Status: `PARTIEL`

| Component | Status | Detail |
|---|---:|---|
| Kubernetes API | TERMINÉ | API server reachable |
| Official deployments | PARTIEL | Availability check for five Laravel workloads |
| HPA objects | TERMINÉ | HPA resources returned for namespace |
| metrics-server | DÉPENDANT_DE_L_ENVIRONNEMENT | kubectl top pods/nodes unavailable |
| PodDisruptionBudget | TERMINÉ | PDB resources returned for namespace |

## Kubernetes context

```text
kind-securerag-dev
```

## Deployments

```text
NAME                     READY   UP-TO-DATE   AVAILABLE   AGE     CONTAINERS               IMAGES                                                     SELECTOR
audit-security-service   1/1     1            1           24d     audit-security-service   localhost:5001/securerag-hub-audit-security-service:demo   app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub
auth-users               1/3     1            1           7d14h   auth-users               localhost:5001/securerag-hub-auth-users:demo               app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub
chatbot-manager          1/1     1            1           24d     chatbot-manager          localhost:5001/securerag-hub-chatbot-manager:demo          app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub
conversation-service     1/1     1            1           24d     conversation-service     localhost:5001/securerag-hub-conversation-service:demo     app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub
portal-web               0/2     1            0           24d     portal-web               localhost:5001/securerag-hub-portal-web:demo               app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub
postgres-auth            1/1     1            1           24d     postgres-auth            localhost:5001/postgres:16-alpine                          app.kubernetes.io/name=postgres-auth,app.kubernetes.io/part-of=securerag-hub
```

## Pods

```text
NAME                                      READY   STATUS    RESTARTS         AGE     IP             NODE                   NOMINATED NODE   READINESS GATES
audit-security-service-5dc8b86497-srmhp   1/1     Running   1 (44h ago)      7d5h    10.244.0.96    securerag-dev-worker   <none>           <none>
auth-users-557c884c45-skbzz               1/1     Running   1 (44h ago)      7d5h    10.244.0.174   securerag-dev-worker   <none>           <none>
chatbot-manager-5c868487d8-gh4sv          1/1     Running   1 (44h ago)      7d5h    10.244.0.251   securerag-dev-worker   <none>           <none>
conversation-service-7678f59b49-fqg8b     1/1     Running   1 (44h ago)      7d5h    10.244.0.116   securerag-dev-worker   <none>           <none>
portal-web-84bd8bb87c-fm7sj               0/1     Running   63 (6m41s ago)   7d14h   10.244.0.137   securerag-dev-worker   <none>           <none>
postgres-auth-fbf55db78-kwlh4             1/1     Running   1 (44h ago)      23d     10.244.0.202   securerag-dev-worker   <none>           <none>
```

## Services

```text
NAME                     TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)          AGE   SELECTOR
audit-security-service   ClusterIP   10.96.104.151   <none>        8000/TCP         24d   app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub
auth-users               ClusterIP   10.96.139.68    <none>        8000/TCP         24d   app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub
chatbot-manager          ClusterIP   10.96.189.113   <none>        8000/TCP         24d   app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub
conversation-service     ClusterIP   10.96.192.110   <none>        8000/TCP         24d   app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub
portal-web               NodePort    10.96.193.87    <none>        8000:30081/TCP   24d   app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub
postgres-auth            ClusterIP   10.96.110.118   <none>        5432/TCP         24d   app.kubernetes.io/name=postgres-auth,app.kubernetes.io/part-of=securerag-hub
```

## ServiceAccounts

```text
NAME                        SECRETS   AGE
default                     0         24d
jenkins                     0         5h37m
jenkins-admin               0         6h9m
sa-audit-security-service   0         24d
sa-auth-users               0         24d
sa-chatbot-manager          0         24d
sa-conversation-service     0         24d
sa-portal-web               0         24d
sa-postgres-auth            0         24d
sa-validation               0         24d
```

## Roles and RoleBindings

```text
NAME                                                        CREATED AT
role.rbac.authorization.k8s.io/securerag-runtime-readonly   2026-06-24T11:03:14Z

NAME                                                                                      ROLE                              AGE   USERS   GROUPS   SERVICEACCOUNTS
rolebinding.rbac.authorization.k8s.io/securerag-runtime-readonly-audit-security-service   Role/securerag-runtime-readonly   24d                    securerag-hub/sa-audit-security-service
```

## PDB

```text
NAME                         MIN AVAILABLE   MAX UNAVAILABLE   ALLOWED DISRUPTIONS   AGE
audit-security-service-pdb   1               N/A               0                     24d
auth-users-pdb               1               N/A               0                     24d
chatbot-manager-pdb          1               N/A               0                     24d
conversation-service-pdb     1               N/A               0                     24d
portal-web-pdb               1               N/A               0                     24d
```

## HPA

```text
NAME         REFERENCE               TARGETS              MINPODS   MAXPODS   REPLICAS   AGE
portal-web   Deployment/portal-web   cpu: <unknown>/70%   1         3         2          24d
```

## ResourceQuota

```text
NAME                  REQUEST                                                                                                                                                                         LIMIT                                                                                  AGE
securerag-hub-quota   persistentvolumeclaims: 0/10, pods: 6/30, requests.cpu: 1100m/6, requests.ephemeral-storage: 896Mi/4Gi, requests.memory: 1408Mi/6Gi, requests.storage: 0/40Gi, services: 6/20   limits.cpu: 4600m/12, limits.ephemeral-storage: 3584Mi/12Gi, limits.memory: 3Gi/12Gi   24d
```

## LimitRange

```text
NAME                     CREATED AT
securerag-hub-defaults   2026-06-24T11:03:13Z
```

## NetworkPolicies

```text
NAME                             POD-SELECTOR                                                                                                    AGE
allow-dns-egress                 <none>                                                                                                          24d
allow-prometheus-scraping        app.kubernetes.io/name in (audit-security-service,auth-users,chatbot-manager,conversation-service,portal-web)   7d19h
allow-validation-egress          app.kubernetes.io/part-of=securerag-hub,job-role=validation                                                     24d
allow-validation-ingress         app.kubernetes.io/name in (audit-security-service,auth-users,chatbot-manager,conversation-service,portal-web)   24d
audit-security-service-network   app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub                           24d
auth-users-policy                app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub                                       24d
chatbot-manager-policy           app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub                                  24d
conversation-service-network     app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub                             24d
default-deny-all                 <none>                                                                                                          24d
portal-web-policy                app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub                                       24d
postgres-auth-policy             app.kubernetes.io/part-of=securerag-hub,cnpg.io/cluster=postgres-auth                                           24d
```

## Pod images and imageIDs

```text
audit-security-service-5dc8b86497-srmhp	localhost:5001/securerag-hub-audit-security-service:demo	localhost:5001/securerag-hub-audit-security-service@sha256:607c582cd366596ca2fe932f46ad20d2a2e2fc5035ceb21b2d3e7ceaddc4de40
auth-users-557c884c45-skbzz	localhost:5001/securerag-hub-auth-users:demo	localhost:5001/securerag-hub-auth-users@sha256:bd41788e6601a3fae482f6fc40f6c11607be1a3a39f1ea091ebed7220134dedf
chatbot-manager-5c868487d8-gh4sv	localhost:5001/securerag-hub-chatbot-manager:demo	localhost:5001/securerag-hub-chatbot-manager@sha256:a6a7cf00fdc32e9cc75b055ed11b528373c484bda23dcbbe72655bb43ee332ea
conversation-service-7678f59b49-fqg8b	localhost:5001/securerag-hub-conversation-service:demo	localhost:5001/securerag-hub-conversation-service@sha256:ca1330835dbf0527e967f7b12a18d741ac956ab3e6763fb66b3b572b7d377c8a
portal-web-84bd8bb87c-fm7sj	localhost:5001/securerag-hub-portal-web:demo	localhost:5001/securerag-hub-portal-web@sha256:d3c1a466bd97669e029ffd591e28e6ac2e63ab8d039f43a1a4a61e02a9e90e91
postgres-auth-fbf55db78-kwlh4	docker.io/library/postgres:16-alpine	docker.io/library/postgres@sha256:e013e867e712fec275706a6c51c966f0bb0c93cfa8f51000f85a15f9865a28cb
```

## Recent events

```text
LAST SEEN   TYPE      REASON                         OBJECT                                        MESSAGE
21m         Warning   PolicyViolation                replicaset/portal-web-5c9c9c5d66              policy securerag-disallow-root-containers/autogen-check-run-as-non-root fail: validation error: Pods must run as non-root (runAsNonRoot: true). rule autogen-check-run-as-non-root failed at path /spec/template/spec/containers/0/securityContext/runAsNonRoot/
70m         Normal    Pulled                         pod/portal-web-84bd8bb87c-fm7sj               Successfully pulled image "localhost:5001/securerag-hub-portal-web:demo" in 10.898s (10.898s including waiting). Image size: 268260149 bytes.
61m         Warning   Unhealthy                      pod/conversation-service-7678f59b49-fqg8b     Liveness probe failed: Get "http://10.244.0.116:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
60m         Warning   Unhealthy                      pod/chatbot-manager-5c868487d8-gh4sv          Liveness probe failed: Get "http://10.244.0.251:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
60m         Warning   Unhealthy                      pod/audit-security-service-5dc8b86497-srmhp   Readiness probe failed: Get "http://10.244.0.96:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
59m         Normal    Pulled                         pod/portal-web-84bd8bb87c-fm7sj               Successfully pulled image "localhost:5001/securerag-hub-portal-web:demo" in 1.397s (1.398s including waiting). Image size: 268260149 bytes.
59m         Warning   Failed                         pod/portal-web-84bd8bb87c-fm7sj               Error: failed to sync configmap cache: timed out waiting for the condition
58m         Warning   Unhealthy                      pod/auth-users-557c884c45-skbzz               Liveness probe failed: Get "http://10.244.0.174:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
57m         Warning   FailedCreate                   replicaset/auth-users-8f47d4955               Error creating: Internal error occurred: failed calling webhook "mutate.kyverno.svc-fail": failed to call webhook: Post "https://kyverno-svc.kyverno.svc:443/mutate/fail?timeout=29s": dial tcp 10.96.113.141:443: connect: operation not permitted
56m         Warning   FailedCreate                   replicaset/auth-users-557c884c45              Error creating: Internal error occurred: failed calling webhook "mutate.kyverno.svc-fail": failed to call webhook: Post "https://kyverno-svc.kyverno.svc:443/mutate/fail?timeout=30s": dial tcp 10.96.113.141:443: connect: operation not permitted
56m         Warning   FailedCreate                   replicaset/portal-web-84bd8bb87c              Error creating: Internal error occurred: failed calling webhook "mutate.kyverno.svc-fail": failed to call webhook: Post "https://kyverno-svc.kyverno.svc:443/mutate/fail?timeout=30s": dial tcp 10.96.113.141:443: connect: operation not permitted
56m         Warning   FailedCreate                   replicaset/auth-users-8f47d4955               Error creating: Internal error occurred: failed calling webhook "mutate.kyverno.svc-fail": failed to call webhook: Post "https://kyverno-svc.kyverno.svc:443/mutate/fail?timeout=30s": dial tcp 10.96.113.141:443: connect: operation not permitted
56m         Warning   FailedComputeMetricsReplicas   horizontalpodautoscaler/portal-web            invalid metrics (1 invalid out of 1), first error is: failed to get cpu resource metric value: failed to get cpu utilization: unable to get metrics for resource cpu: unable to fetch metrics from resource metrics API: the server is currently unable to handle the request (get pods.metrics.k8s.io)
56m         Warning   FailedGetResourceMetric        horizontalpodautoscaler/portal-web            failed to get cpu utilization: unable to get metrics for resource cpu: unable to fetch metrics from resource metrics API: the server is currently unable to handle the request (get pods.metrics.k8s.io)
51m         Normal    Killing                        pod/portal-web-84bd8bb87c-fm7sj               Container portal-web failed startup probe, will be restarted
46m         Warning   Unhealthy                      pod/audit-security-service-5dc8b86497-srmhp   Liveness probe failed: Get "http://10.244.0.96:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
41m         Normal    Pulled                         pod/portal-web-84bd8bb87c-fm7sj               Successfully pulled image "localhost:5001/securerag-hub-portal-web:demo" in 2.797s (2.797s including waiting). Image size: 268260149 bytes.
35m         Normal    Created                        pod/portal-web-84bd8bb87c-fm7sj               Created container: portal-web
30m         Warning   BackOff                        pod/portal-web-84bd8bb87c-fm7sj               Back-off restarting failed container portal-web in pod portal-web-84bd8bb87c-fm7sj_securerag-hub(d11acadd-fcfb-4a6e-8ac3-2f0b40202c04)
28m         Normal    Pulling                        pod/portal-web-84bd8bb87c-fm7sj               Pulling image "localhost:5001/securerag-hub-portal-web:demo"
28m         Warning   Unhealthy                      pod/postgres-auth-fbf55db78-kwlh4             Readiness probe failed: command timed out: "pg_isready -U securerag -d auth_users" timed out after 3s
24m         Warning   Unhealthy                      pod/conversation-service-7678f59b49-fqg8b     Readiness probe failed: Get "http://10.244.0.116:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
24m         Warning   Unhealthy                      pod/chatbot-manager-5c868487d8-gh4sv          Readiness probe failed: Get "http://10.244.0.251:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
24m         Normal    Started                        pod/portal-web-84bd8bb87c-fm7sj               Started container portal-web
24m         Warning   Unhealthy                      pod/auth-users-557c884c45-skbzz               Readiness probe failed: Get "http://10.244.0.174:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
23m         Warning   Unhealthy                      pod/portal-web-84bd8bb87c-fm7sj               Startup probe failed: Get "http://10.244.0.137:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
22m         Warning   Unhealthy                      pod/postgres-auth-fbf55db78-kwlh4             Liveness probe failed: command timed out: "pg_isready -U securerag -d auth_users" timed out after 3s
```

## Metrics APIService

```text
NAME                     SERVICE                      AVAILABLE                  AGE
v1beta1.metrics.k8s.io   kube-system/metrics-server   False (MissingEndpoints)   12d
```

## Node metrics

```text
error: Metrics API not available
```

## Pod metrics

```text
error: Metrics API not available
```

## Describe deployment/portal-web

```text
Name:                   portal-web
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
                        argocd.argoproj.io/instance=securerag-recette
Annotations:            deployment.kubernetes.io/revision: 103
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-portal-web:demo":"pass"}
                        prometheus.io/path: /metrics
                        prometheus.io/port: 8000
                        prometheus.io/scrape: true
Selector:               app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub
Replicas:               2 desired | 1 updated | 1 total | 0 available | 2 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  0 max unavailable, 1 max surge
Pod Template:
  Labels:           app.kubernetes.io/name=portal-web
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-07-10T20:36:47+02:00
                    prometheus.io/path: /metrics
                    prometheus.io/port: 8000
                    prometheus.io/scrape: true
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-portal-web
  Containers:
   portal-web:
    Image:      localhost:5001/securerag-hub-portal-web:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                400m
      ephemeral-storage:  1Gi
      memory:             512Mi
    Requests:
      cpu:                100m
      ephemeral-storage:  256Mi
      memory:             128Mi
    Liveness:             http-get http://:http/health delay=30s timeout=3s period=20s #success=1 #failure=3
    Readiness:            http-get http://:http/health delay=10s timeout=3s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      APP_ENV:                        production
      APP_DEBUG:                      false
      INTERNAL_SERVICE_SCHEME:        http
      APP_URL:                        $(INTERNAL_SERVICE_SCHEME)://portal-web:8000
      DB_CONNECTION:                  sqlite
      DB_DATABASE:                    /tmp/securerag-runtime/database/database.sqlite
      SESSION_DRIVER:                 file
      CACHE_STORE:                    file
      LOG_CHANNEL:                    stderr
      CREATE_DOTENV:                  false
      QUEUE_CONNECTION:               nats
      NATS_URL:                       nats://nats.ai-security.svc.cluster.local:4222
      SECURERAG_PORTAL_BACKEND_MODE:  auto
      AUTH_USERS_BASE_URL:            $(INTERNAL_SERVICE_SCHEME)://auth-users:8000
      CHATBOT_MANAGER_BASE_URL:       $(INTERNAL_SERVICE_SCHEME)://chatbot-manager:8000
      CONVERSATION_BASE_URL:          $(INTERNAL_SERVICE_SCHEME)://conversation-service:8000
      AUDIT_SECURITY_BASE_URL:        $(INTERNAL_SERVICE_SCHEME)://audit-security-service:8000
    Mounts:
      /tmp from tmp (rw)
      /var/www/html/bootstrap/cache from app-cache (rw)
      /var/www/html/storage from app-storage (rw)
  Volumes:
   app-storage:
    Type:       EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:     
    SizeLimit:  <unset>
   app-cache:
    Type:       EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:     
    SizeLimit:  <unset>
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type             Status  Reason
  ----             ------  ------
  Progressing      True    NewReplicaSetAvailable
  Available        False   MinimumReplicasUnavailable
  ReplicaFailure   True    FailedCreate
OldReplicaSets:    portal-web-5898f9c5cd (0/0 replicas created), portal-web-859c78db95 (0/0 replicas created), portal-web-7f59b76ccd (0/0 replicas created), portal-web-588b497f88 (0/0 replicas created), portal-web-5c9c9c5d66 (0/0 replicas created), portal-web-5967644c8 (0/0 replicas created), portal-web-548bf768cc (0/0 replicas created), portal-web-7f59d969c (0/0 replicas created), portal-web-77bdb897d7 (0/0 replicas created), portal-web-599f478c6c (0/0 replicas created)
NewReplicaSet:     portal-web-84bd8bb87c (1/2 replicas created)
Events:            <none>
```

## Logs deployment/portal-web

```text

   INFO  Nothing to migrate.  


   INFO  Server running on [http://0.0.0.0:8000].  

  Press Ctrl+C to stop the server

  2026-07-18 13:17:38 ............................................ ~ 496.68ms
  2026-07-18 13:17:41 /health ......................................... ~ 40s
  2026-07-18 13:17:47 /health ......................................... ~ 38s
```

## Describe deployment/auth-users

```text
Name:                   auth-users
Namespace:              securerag-hub
CreationTimestamp:      Sat, 11 Jul 2026 00:58:13 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
                        argocd.argoproj.io/instance=securerag-recette
Annotations:            deployment.kubernetes.io/revision: 32
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-auth-users:demo":"pass"}
Selector:               app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub
Replicas:               3 desired | 1 updated | 1 total | 1 available | 3 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:           app.kubernetes.io/name=auth-users
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-auth-users
  Containers:
   auth-users:
    Image:      localhost:5001/securerag-hub-auth-users:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                800m
      ephemeral-storage:  512Mi
      memory:             512Mi
    Requests:
      cpu:                200m
      ephemeral-storage:  128Mi
      memory:             256Mi
    Liveness:             http-get http://:http/health delay=15s timeout=10s period=20s #success=1 #failure=6
    Readiness:            http-get http://:http/health delay=5s timeout=10s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      OTEL_PHP_AUTOLOAD_ENABLED:    true
      OTEL_TRACES_EXPORTER:         otlp
      OTEL_EXPORTER_OTLP_ENDPOINT:  $(INTERNAL_SERVICE_SCHEME)://otel-collector.otel-system.svc.cluster.local:4318
      OTEL_SERVICE_NAME:            auth-users
      SERVICE_NAME:                 auth-users-service
      INTERNAL_SERVICE_SCHEME:      http
      APP_ENV:                      production
      APP_DEBUG:                    false
      APP_URL:                      $(INTERNAL_SERVICE_SCHEME)://auth-users:8000
      DB_CONNECTION:                pgsql
      DB_HOST:                      postgres-auth
      DB_PORT:                      5432
      DB_DATABASE:                  auth_users
      DB_USERNAME:                  securerag
      DB_SSLMODE:                   disable
      SESSION_DRIVER:               file
      CACHE_STORE:                  file
      QUEUE_CONNECTION:             nats
      NATS_URL:                     nats://nats.ai-security.svc.cluster.local:4222
      LOG_CHANNEL:                  stderr
      CREATE_DOTENV:                false
      SECURERAG_AUTHZ_ALLOW_LOCAL:  false
    Mounts:
      /tmp from tmp (rw)
  Volumes:
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type             Status  Reason
  ----             ------  ------
  ReplicaFailure   True    FailedCreate
  Available        False   MinimumReplicasUnavailable
  Progressing      False   ProgressDeadlineExceeded
OldReplicaSets:    auth-users-74ff9d7df7 (0/0 replicas created), auth-users-8f47d4955 (0/2 replicas created)
NewReplicaSet:     auth-users-557c884c45 (1/2 replicas created)
Events:            <none>
```

## Logs deployment/auth-users

```text
  2026-07-18 13:11:14 /health .......................................... ~ 1s
  2026-07-18 13:11:23 /health .......................................... ~ 4s
  2026-07-18 13:11:27 /health .......................................... ~ 1s
  2026-07-18 13:11:33 /health .......................................... ~ 3s
  2026-07-18 13:11:43 /health .................................... ~ 703.61ms
  2026-07-18 13:11:50 /health .......................................... ~ 2s
  2026-07-18 13:11:53 /health ...................................... ~ 2.67ms
  2026-07-18 13:12:04 /health .......................................... ~ 3s
  2026-07-18 13:12:16 /health .......................................... ~ 3s
  2026-07-18 13:12:16 /health .......................................... ~ 7s
  2026-07-18 13:12:23 /health .......................................... ~ 1s
  2026-07-18 13:12:33 /health .......................................... ~ 1s
  2026-07-18 13:12:29 /health .......................................... ~ 5s
  2026-07-18 13:12:47 /health .......................................... ~ 5s
  2026-07-18 13:12:47 /health .......................................... ~ 4s
  2026-07-18 13:12:56 /health .......................................... ~ 7s
  2026-07-18 13:13:05 /health .......................................... ~ 1s
  2026-07-18 13:13:07 /health .......................................... ~ 2s
  2026-07-18 13:13:15 /health .......................................... ~ 2s
  2026-07-18 13:13:23 /health .......................................... ~ 2s
  2026-07-18 13:13:27 /health .......................................... ~ 1s
  2026-07-18 13:13:33 /health .......................................... ~ 1s
  2026-07-18 13:13:43 /health .................................... ~ 604.94ms
  2026-07-18 13:13:47 /health .......................................... ~ 1s
  2026-07-18 13:13:53 /health .......................................... ~ 2s
  2026-07-18 13:14:03 /health .......................................... ~ 5s
  2026-07-18 13:14:08 /health .......................................... ~ 1s
  2026-07-18 13:14:13 /health .......................................... ~ 2s
  2026-07-18 13:14:24 /health .......................................... ~ 3s
  2026-07-18 13:14:28 /health .................................... ~ 908.31ms
  2026-07-18 13:14:33 /health .......................................... ~ 1s
  2026-07-18 13:14:43 /health .......................................... ~ 4s
  2026-07-18 13:14:47 /health .......................................... ~ 3s
  2026-07-18 13:14:54 /health .......................................... ~ 2s
  2026-07-18 13:15:03 /health .......................................... ~ 3s
  2026-07-18 13:15:07 /health .......................................... ~ 1s
  2026-07-18 13:15:14 /health .......................................... ~ 1s
  2026-07-18 13:15:25 /health .................................... ~ 506.80ms
  2026-07-18 13:15:28 /health .................................... ~ 699.91ms
  2026-07-18 13:15:33 /health .......................................... ~ 3s
  2026-07-18 13:15:44 /health .......................................... ~ 1s
  2026-07-18 13:15:47 /health .......................................... ~ 1s
  2026-07-18 13:15:57 /health .......................................... ~ 1s
  2026-07-18 13:16:04 /health .......................................... ~ 2s
  2026-07-18 13:16:07 /health .......................................... ~ 1s
  2026-07-18 13:16:13 /health .......................................... ~ 2s
  2026-07-18 13:16:27 /health .......................................... ~ 4s
  2026-07-18 13:16:30 /health .......................................... ~ 4s
  2026-07-18 13:16:34 /health .......................................... ~ 1s
  2026-07-18 13:16:43 /health .......................................... ~ 1s
  2026-07-18 13:16:47 /health .......................................... ~ 1s
  2026-07-18 13:16:53 /health .......................................... ~ 2s
  2026-07-18 13:17:04 /health .......................................... ~ 1s
  2026-07-18 13:17:07 /health ...................................... ~ 0.08ms
  2026-07-18 13:17:13 /health .......................................... ~ 3s
  2026-07-18 13:17:23 /health .......................................... ~ 1s
  2026-07-18 13:17:27 /health .......................................... ~ 4s
  2026-07-18 13:17:34 /health .......................................... ~ 4s
  2026-07-18 13:17:43 /health .......................................... ~ 1s
  2026-07-18 13:17:47 /health .......................................... ~ 2s
  2026-07-18 13:17:53 /health .......................................... ~ 3s
  2026-07-18 13:18:03 /health .......................................... ~ 2s
  2026-07-18 13:18:08 /health .......................................... ~ 2s
  2026-07-18 13:18:14 /health .......................................... ~ 2s
  2026-07-18 13:18:23 /health .................................... ~ 505.08ms
  2026-07-18 13:18:27 /health .......................................... ~ 2s
  2026-07-18 13:18:33 /health .......................................... ~ 1s
  2026-07-18 13:18:43 /health .......................................... ~ 1s
  2026-07-18 13:18:48 /health .......................................... ~ 1s
  2026-07-18 13:18:54 /health .......................................... ~ 2s
  2026-07-18 13:19:03 /health .......................................... ~ 1s
  2026-07-18 13:19:07 /health .......................................... ~ 3s
  2026-07-18 13:19:13 /health .......................................... ~ 1s
  2026-07-18 13:19:23 /health .......................................... ~ 1s
  2026-07-18 13:19:27 /health .......................................... ~ 2s
  2026-07-18 13:19:33 /health .......................................... ~ 1s
  2026-07-18 13:19:43 /health .................................... ~ 588.84ms
  2026-07-18 13:19:47 /health .......................................... ~ 1s
  2026-07-18 13:19:53 /health .......................................... ~ 2s
  2026-07-18 13:20:04 /health .......................................... ~ 2s
  2026-07-18 13:20:07 /health .......................................... ~ 1s
  2026-07-18 13:20:14 /health .......................................... ~ 1s
  2026-07-18 13:20:23 /health .......................................... ~ 3s
  2026-07-18 13:20:29 /health .......................................... ~ 1s
  2026-07-18 13:20:33 /health .......................................... ~ 3s
  2026-07-18 13:20:43 /health .......................................... ~ 2s
  2026-07-18 13:20:48 /health .......................................... ~ 3s
  2026-07-18 13:20:53 /health .................................... ~ 601.50ms
  2026-07-18 13:21:03 /health .......................................... ~ 3s
  2026-07-18 13:21:08 /health .......................................... ~ 2s
  2026-07-18 13:21:14 /health .......................................... ~ 1s
  2026-07-18 13:21:27 /health .................................... ~ 602.09ms
  2026-07-18 13:21:23 /health .......................................... ~ 7s
  2026-07-18 13:21:34 /health .......................................... ~ 1s
  2026-07-18 13:21:44 /health .......................................... ~ 1s
  2026-07-18 13:21:47 /health .......................................... ~ 2s
  2026-07-18 13:21:56 /health .......................................... ~ 6s
  2026-07-18 13:22:03 /health .......................................... ~ 1s
  2026-07-18 13:22:08 /health .......................................... ~ 2s
  2026-07-18 13:22:14 /health .......................................... ~ 2s
  2026-07-18 13:22:28 /health .......................................... ~ 2s
  2026-07-18 13:22:29 /health .......................................... ~ 2s
  2026-07-18 13:22:33 /health .......................................... ~ 2s
  2026-07-18 13:22:43 /health .......................................... ~ 4s
  2026-07-18 13:22:47 /health .......................................... ~ 3s
  2026-07-18 13:22:55 /health .......................................... ~ 1s
  2026-07-18 13:23:07 /health .......................................... ~ 1s
  2026-07-18 13:23:07 /health .......................................... ~ 2s
  2026-07-18 13:23:13 /health .......................................... ~ 1s
  2026-07-18 13:23:23 /health .......................................... ~ 2s
  2026-07-18 13:23:27 /health .......................................... ~ 3s
  2026-07-18 13:23:33 /health .......................................... ~ 1s
  2026-07-18 13:23:43 /health .......................................... ~ 1s
  2026-07-18 13:23:48 /health .......................................... ~ 5s
  2026-07-18 13:23:54 /health .......................................... ~ 2s
  2026-07-18 13:24:04 /health .......................................... ~ 3s
  2026-07-18 13:24:08 /health .......................................... ~ 1s
  2026-07-18 13:24:14 /health .......................................... ~ 1s
  2026-07-18 13:24:23 /health .......................................... ~ 4s
  2026-07-18 13:24:27 /health ...................................... ~ 0.02ms
```

## Describe deployment/chatbot-manager

```text
Name:                   chatbot-manager
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
                        argocd.argoproj.io/instance=securerag-recette
Annotations:            deployment.kubernetes.io/revision: 65
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-chatbot-manager:demo":"pass"}
                        prometheus.io/path: /metrics
                        prometheus.io/port: 8000
                        prometheus.io/scrape: true
Selector:               app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub
Replicas:               1 desired | 1 updated | 1 total | 1 available | 0 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:           app.kubernetes.io/name=chatbot-manager
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-07-10T20:36:47+02:00
                    prometheus.io/path: /metrics
                    prometheus.io/port: 8000
                    prometheus.io/scrape: true
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-chatbot-manager
  Containers:
   chatbot-manager:
    Image:      localhost:5001/securerag-hub-chatbot-manager:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                800m
      ephemeral-storage:  512Mi
      memory:             512Mi
    Requests:
      cpu:                200m
      ephemeral-storage:  128Mi
      memory:             256Mi
    Liveness:             http-get http://:http/health delay=15s timeout=10s period=20s #success=1 #failure=6
    Readiness:            http-get http://:http/health delay=5s timeout=10s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      OTEL_PHP_AUTOLOAD_ENABLED:    true
      OTEL_TRACES_EXPORTER:         otlp
      OTEL_EXPORTER_OTLP_ENDPOINT:  $(INTERNAL_SERVICE_SCHEME)://otel-collector.otel-system.svc.cluster.local:4318
      OTEL_SERVICE_NAME:            chatbot-manager
      SERVICE_NAME:                 chatbot-manager-service
      INTERNAL_SERVICE_SCHEME:      http
      AUTH_USERS_URL:               $(INTERNAL_SERVICE_SCHEME)://auth-users:8000
      APP_ENV:                      production
      APP_DEBUG:                    false
      APP_URL:                      $(INTERNAL_SERVICE_SCHEME)://chatbot-manager:8000
      DB_CONNECTION:                sqlite
      DB_DATABASE:                  /tmp/securerag-runtime/database/database.sqlite
      SESSION_DRIVER:               file
      CACHE_STORE:                  file
      QUEUE_CONNECTION:             nats
      NATS_URL:                     nats://nats.ai-security.svc.cluster.local:4222
      LOG_CHANNEL:                  stderr
      CREATE_DOTENV:                false
      SECURERAG_AUTHZ_ALLOW_LOCAL:  false
    Mounts:
      /tmp from tmp (rw)
  Volumes:
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type           Status  Reason
  ----           ------  ------
  Progressing    True    NewReplicaSetAvailable
  Available      True    MinimumReplicasAvailable
OldReplicaSets:  chatbot-manager-54b9bb64f8 (0/0 replicas created), chatbot-manager-7747c5c74c (0/0 replicas created), chatbot-manager-6d6958b667 (0/0 replicas created), chatbot-manager-58d8fdb94f (0/0 replicas created), chatbot-manager-79b79d59c4 (0/0 replicas created), chatbot-manager-648b486f4f (0/0 replicas created), chatbot-manager-6495b5556 (0/0 replicas created), chatbot-manager-5b9d9fd58 (0/0 replicas created), chatbot-manager-6f559d96db (0/0 replicas created), chatbot-manager-7586fb94f6 (0/0 replicas created)
NewReplicaSet:   chatbot-manager-5c868487d8 (1/1 replicas created)
Events:          <none>
```

## Logs deployment/chatbot-manager

```text
  #1 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(243): Illuminate\\Routing\\CallableDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Closure))
  #2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(214): Illuminate\\Routing\\Route->runCallable()
  #3 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(822): Illuminate\\Routing\\Route->run()
  #4 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Routing\\Router->{closure:Illuminate\\Routing\\Router::runRouteWithinStack():821}(Object(Illuminate\\Http\\Request))
  #5 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(50): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #6 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #7 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/VerifyCsrfToken.php(87): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(48): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #10 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #11 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(120): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #12 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest(Object(Illuminate\\Http\\Request), Object(Illuminate\\Session\\Store), Object(Closure))
  #13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #14 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(36): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #15 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #16 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(74): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #17 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #19 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(821): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #20 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(800): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))
  #21 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(764): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))
  #22 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(753): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))
  #23 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(200): Illuminate\\Routing\\Router->dispatch(Object(Illuminate\\Http\\Request))
  #24 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Foundation\\Http\\Kernel->{closure:Illuminate\\Foundation\\Http\\Kernel::dispatchToRouter():197}(Object(Illuminate\\Http\\Request))
  #25 /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php(134): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #27 /var/www/shared-security/src/Http/Middleware/SecurityHeaders.php(16): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\SecurityHeaders->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #29 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #30 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/ConvertEmptyStringsToNull.php(31): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\ConvertEmptyStringsToNull->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #32 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TrimStrings.php(51): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #34 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\TrimStrings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #35 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePostSize.php(27): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #36 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePostSize->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #37 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php(109): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #38 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\PreventRequestsDuringMaintenance->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #39 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/HandleCors.php(61): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #40 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\HandleCors->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #41 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/TrustProxies.php(58): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #42 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\TrustProxies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/InvokeDeferredCallbacks.php(22): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #44 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\InvokeDeferredCallbacks->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #45 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePathEncoding.php(26): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #46 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePathEncoding->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #47 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #48 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(175): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #49 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(144): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))
  #50 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1220): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))
  #51 /var/www/html/public/index.php(20): Illuminate\\Foundation\\Application->handleRequest(Object(Illuminate\\Http\\Request))
  #52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/resources/server.php(23): require_once('/var/www/html/p...')
  #53 {main}
  "}
  2026-07-18 13:24:00 /metrics ......................................... ~ 6s
  2026-07-18 13:24:06 /health .......................................... ~ 1s
  2026-07-18 13:24:16 /health .......................................... ~ 5s
  2026-07-18 13:24:18 /health .......................................... ~ 2s
  2026-07-18 13:24:27 /health .................................... ~ 500.47ms
  production.ERROR: Call to undefined method Prometheus\CollectorRegistry::getMetricFamilies() {"exception":"[object] (Error(code: 0): Call to undefined method Prometheus\\CollectorRegistry::getMetricFamilies() at /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php:121)
  [stacktrace]
  #0 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/CallableDispatcher.php(39): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware::{closure:SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware::registerRoutes():88}(Object(Illuminate\\Http\\Request))
  #1 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(243): Illuminate\\Routing\\CallableDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Closure))
  #2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(214): Illuminate\\Routing\\Route->runCallable()
  #3 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(822): Illuminate\\Routing\\Route->run()
  #4 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Routing\\Router->{closure:Illuminate\\Routing\\Router::runRouteWithinStack():821}(Object(Illuminate\\Http\\Request))
  #5 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(50): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #6 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #7 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/VerifyCsrfToken.php(87): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(48): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #10 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #11 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(120): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #12 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest(Object(Illuminate\\Http\\Request), Object(Illuminate\\Session\\Store), Object(Closure))
  #13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #14 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(36): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #15 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #16 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(74): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #17 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #19 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(821): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #20 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(800): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))
  #21 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(764): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))
  #22 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(753): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))
  #23 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(200): Illuminate\\Routing\\Router->dispatch(Object(Illuminate\\Http\\Request))
  #24 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Foundation\\Http\\Kernel->{closure:Illuminate\\Foundation\\Http\\Kernel::dispatchToRouter():197}(Object(Illuminate\\Http\\Request))
  #25 /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php(134): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #27 /var/www/shared-security/src/Http/Middleware/SecurityHeaders.php(16): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\SecurityHeaders->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #29 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #30 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/ConvertEmptyStringsToNull.php(31): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\ConvertEmptyStringsToNull->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #32 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TrimStrings.php(51): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #34 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\TrimStrings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #35 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePostSize.php(27): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #36 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePostSize->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #37 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php(109): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #38 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\PreventRequestsDuringMaintenance->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #39 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/HandleCors.php(61): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #40 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\HandleCors->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #41 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/TrustProxies.php(58): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #42 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\TrustProxies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/InvokeDeferredCallbacks.php(22): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #44 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\InvokeDeferredCallbacks->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #45 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePathEncoding.php(26): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #46 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePathEncoding->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #47 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #48 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(175): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #49 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(144): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))
  #50 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1220): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))
  #51 /var/www/html/public/index.php(20): Illuminate\\Foundation\\Application->handleRequest(Object(Illuminate\\Http\\Request))
  #52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/resources/server.php(23): require_once('/var/www/html/p...')
  #53 {main}
  "}
  2026-07-18 13:24:30 /metrics ................................... ~ 502.36ms
  2026-07-18 13:24:37 /health .......................................... ~ 2s
  2026-07-18 13:24:38 /health .......................................... ~ 3s
  2026-07-18 13:24:46 /health .......................................... ~ 1s
```

## Describe deployment/conversation-service

```text
Name:                   conversation-service
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
                        argocd.argoproj.io/instance=securerag-recette
Annotations:            deployment.kubernetes.io/revision: 65
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-conversation-service:demo":"pass"}
                        prometheus.io/path: /metrics
                        prometheus.io/port: 8000
                        prometheus.io/scrape: true
Selector:               app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub
Replicas:               1 desired | 1 updated | 1 total | 1 available | 0 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:           app.kubernetes.io/name=conversation-service
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-07-10T20:36:47+02:00
                    prometheus.io/path: /metrics
                    prometheus.io/port: 8000
                    prometheus.io/scrape: true
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-conversation-service
  Containers:
   conversation-service:
    Image:      localhost:5001/securerag-hub-conversation-service:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                800m
      ephemeral-storage:  512Mi
      memory:             512Mi
    Requests:
      cpu:                200m
      ephemeral-storage:  128Mi
      memory:             256Mi
    Liveness:             http-get http://:http/health delay=15s timeout=10s period=20s #success=1 #failure=6
    Readiness:            http-get http://:http/health delay=5s timeout=10s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      OTEL_PHP_AUTOLOAD_ENABLED:    true
      OTEL_TRACES_EXPORTER:         otlp
      OTEL_EXPORTER_OTLP_ENDPOINT:  $(INTERNAL_SERVICE_SCHEME)://otel-collector.otel-system.svc.cluster.local:4318
      OTEL_SERVICE_NAME:            conversation-service
      SERVICE_NAME:                 conversation-service
      INTERNAL_SERVICE_SCHEME:      http
      APP_ENV:                      production
      APP_DEBUG:                    false
      APP_URL:                      $(INTERNAL_SERVICE_SCHEME)://conversation-service:8000
      DB_CONNECTION:                sqlite
      DB_DATABASE:                  /tmp/securerag-runtime/database/database.sqlite
      SESSION_DRIVER:               file
      CACHE_STORE:                  file
      QUEUE_CONNECTION:             nats
      NATS_URL:                     nats://nats.ai-security.svc.cluster.local:4222
      LOG_CHANNEL:                  stderr
      CREATE_DOTENV:                false
      SECURERAG_AUTHZ_ALLOW_LOCAL:  false
    Mounts:
      /tmp from tmp (rw)
  Volumes:
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type           Status  Reason
  ----           ------  ------
  Progressing    True    NewReplicaSetAvailable
  Available      True    MinimumReplicasAvailable
OldReplicaSets:  conversation-service-85fbdc56b5 (0/0 replicas created), conversation-service-5ffc5d5ff6 (0/0 replicas created), conversation-service-694d9d678d (0/0 replicas created), conversation-service-55b9dcbc4 (0/0 replicas created), conversation-service-6bc4c7dbc6 (0/0 replicas created), conversation-service-6fb95765f5 (0/0 replicas created), conversation-service-5cf55dcc7f (0/0 replicas created), conversation-service-75f6978f87 (0/0 replicas created), conversation-service-7875d66875 (0/0 replicas created), conversation-service-748d585b85 (0/0 replicas created)
NewReplicaSet:   conversation-service-7678f59b49 (1/1 replicas created)
Events:          <none>
```

## Logs deployment/conversation-service

```text
  [stacktrace]
  #0 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/CallableDispatcher.php(39): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware::{closure:SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware::registerRoutes():88}(Object(Illuminate\\Http\\Request))
  #1 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(243): Illuminate\\Routing\\CallableDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Closure))
  #2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(214): Illuminate\\Routing\\Route->runCallable()
  #3 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(822): Illuminate\\Routing\\Route->run()
  #4 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Routing\\Router->{closure:Illuminate\\Routing\\Router::runRouteWithinStack():821}(Object(Illuminate\\Http\\Request))
  #5 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(50): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #6 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #7 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/VerifyCsrfToken.php(87): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(48): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #10 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #11 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(120): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #12 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest(Object(Illuminate\\Http\\Request), Object(Illuminate\\Session\\Store), Object(Closure))
  #13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #14 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(36): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #15 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #16 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(74): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #17 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #19 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(821): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #20 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(800): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))
  #21 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(764): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))
  #22 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(753): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))
  #23 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(200): Illuminate\\Routing\\Router->dispatch(Object(Illuminate\\Http\\Request))
  #24 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Foundation\\Http\\Kernel->{closure:Illuminate\\Foundation\\Http\\Kernel::dispatchToRouter():197}(Object(Illuminate\\Http\\Request))
  #25 /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php(134): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #27 /var/www/shared-security/src/Http/Middleware/SecurityHeaders.php(16): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\SecurityHeaders->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #29 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #30 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/ConvertEmptyStringsToNull.php(31): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\ConvertEmptyStringsToNull->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #32 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TrimStrings.php(51): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #34 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\TrimStrings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #35 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePostSize.php(27): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #36 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePostSize->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #37 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php(109): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #38 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\PreventRequestsDuringMaintenance->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #39 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/HandleCors.php(61): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #40 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\HandleCors->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #41 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/TrustProxies.php(58): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #42 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\TrustProxies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/InvokeDeferredCallbacks.php(22): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #44 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\InvokeDeferredCallbacks->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #45 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePathEncoding.php(26): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #46 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePathEncoding->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #47 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #48 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(175): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #49 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(144): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))
  #50 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1220): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))
  #51 /var/www/html/public/index.php(20): Illuminate\\Foundation\\Application->handleRequest(Object(Illuminate\\Http\\Request))
  #52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/resources/server.php(23): require_once('/var/www/html/p...')
  #53 {main}
  "}
  2026-07-18 13:24:59 /metrics ................................... ~ 592.61ms
  2026-07-18 13:25:03 /health .......................................... ~ 1s
  2026-07-18 13:25:03 /health .......................................... ~ 2s
  2026-07-18 13:25:15 /health ...................................... ~ 0.08ms
  2026-07-18 13:25:24 /health .......................................... ~ 4s
  2026-07-18 13:25:24 /health .......................................... ~ 6s
  production.ERROR: Call to undefined method Prometheus\CollectorRegistry::getMetricFamilies() {"exception":"[object] (Error(code: 0): Call to undefined method Prometheus\\CollectorRegistry::getMetricFamilies() at /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php:121)
  [stacktrace]
  #0 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/CallableDispatcher.php(39): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware::{closure:SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware::registerRoutes():88}(Object(Illuminate\\Http\\Request))
  #1 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(243): Illuminate\\Routing\\CallableDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Closure))
  #2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(214): Illuminate\\Routing\\Route->runCallable()
  #3 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(822): Illuminate\\Routing\\Route->run()
  #4 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Routing\\Router->{closure:Illuminate\\Routing\\Router::runRouteWithinStack():821}(Object(Illuminate\\Http\\Request))
  #5 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(50): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #6 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #7 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/VerifyCsrfToken.php(87): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(48): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #10 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #11 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(120): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #12 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest(Object(Illuminate\\Http\\Request), Object(Illuminate\\Session\\Store), Object(Closure))
  #13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #14 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(36): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #15 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #16 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(74): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #17 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #19 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(821): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #20 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(800): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))
  #21 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(764): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))
  #22 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(753): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))
  #23 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(200): Illuminate\\Routing\\Router->dispatch(Object(Illuminate\\Http\\Request))
  #24 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Foundation\\Http\\Kernel->{closure:Illuminate\\Foundation\\Http\\Kernel::dispatchToRouter():197}(Object(Illuminate\\Http\\Request))
  #25 /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php(134): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #27 /var/www/shared-security/src/Http/Middleware/SecurityHeaders.php(16): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\SecurityHeaders->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #29 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #30 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/ConvertEmptyStringsToNull.php(31): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\ConvertEmptyStringsToNull->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #32 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TrimStrings.php(51): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #34 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\TrimStrings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #35 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePostSize.php(27): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #36 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePostSize->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #37 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php(109): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #38 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\PreventRequestsDuringMaintenance->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #39 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/HandleCors.php(61): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #40 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\HandleCors->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #41 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/TrustProxies.php(58): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #42 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\TrustProxies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/InvokeDeferredCallbacks.php(22): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #44 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\InvokeDeferredCallbacks->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #45 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePathEncoding.php(26): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #46 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePathEncoding->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #47 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #48 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(175): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #49 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(144): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))
  #50 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1220): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))
  #51 /var/www/html/public/index.php(20): Illuminate\\Foundation\\Application->handleRequest(Object(Illuminate\\Http\\Request))
  #52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/resources/server.php(23): require_once('/var/www/html/p...')
  #53 {main}
  "}
  2026-07-18 13:25:30 /metrics ................................... ~ 705.87ms
```

## Describe deployment/audit-security-service

```text
Name:                   audit-security-service
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
                        argocd.argoproj.io/instance=securerag-recette
Annotations:            deployment.kubernetes.io/revision: 63
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-audit-security-service:demo":"pass"}
                        prometheus.io/path: /metrics
                        prometheus.io/port: 8000
                        prometheus.io/scrape: true
Selector:               app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub
Replicas:               1 desired | 1 updated | 1 total | 1 available | 0 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:           app.kubernetes.io/name=audit-security-service
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-07-10T20:36:47+02:00
                    prometheus.io/path: /metrics
                    prometheus.io/port: 8000
                    prometheus.io/scrape: true
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-audit-security-service
  Containers:
   audit-security-service:
    Image:      localhost:5001/securerag-hub-audit-security-service:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                800m
      ephemeral-storage:  512Mi
      memory:             512Mi
    Requests:
      cpu:                200m
      ephemeral-storage:  128Mi
      memory:             256Mi
    Liveness:             http-get http://:http/health delay=15s timeout=10s period=20s #success=1 #failure=6
    Readiness:            http-get http://:http/health delay=5s timeout=10s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      OTEL_PHP_AUTOLOAD_ENABLED:    true
      OTEL_TRACES_EXPORTER:         otlp
      OTEL_EXPORTER_OTLP_ENDPOINT:  $(INTERNAL_SERVICE_SCHEME)://otel-collector.otel-system.svc.cluster.local:4318
      OTEL_SERVICE_NAME:            audit-security-service
      SERVICE_NAME:                 audit-security-service
      INTERNAL_SERVICE_SCHEME:      http
      APP_ENV:                      production
      APP_DEBUG:                    false
      APP_URL:                      $(INTERNAL_SERVICE_SCHEME)://audit-security-service:8000
      DB_CONNECTION:                sqlite
      DB_DATABASE:                  /tmp/securerag-runtime/database/database.sqlite
      SESSION_DRIVER:               file
      CACHE_STORE:                  file
      QUEUE_CONNECTION:             nats
      NATS_URL:                     nats://nats.ai-security.svc.cluster.local:4222
      LOG_CHANNEL:                  stderr
      CREATE_DOTENV:                false
      SECURERAG_AUTHZ_ALLOW_LOCAL:  false
    Mounts:
      /tmp from tmp (rw)
  Volumes:
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type           Status  Reason
  ----           ------  ------
  Progressing    True    NewReplicaSetAvailable
  Available      True    MinimumReplicasAvailable
OldReplicaSets:  audit-security-service-6c44bb459c (0/0 replicas created), audit-security-service-bdc97f8f6 (0/0 replicas created), audit-security-service-85976dc85b (0/0 replicas created), audit-security-service-585f5dc795 (0/0 replicas created), audit-security-service-667b7997b4 (0/0 replicas created), audit-security-service-7466d4686c (0/0 replicas created), audit-security-service-78c49d959f (0/0 replicas created), audit-security-service-6c79b48cc7 (0/0 replicas created), audit-security-service-6d858c9c5c (0/0 replicas created), audit-security-service-68c6959445 (0/0 replicas created)
NewReplicaSet:   audit-security-service-5dc8b86497 (1/1 replicas created)
Events:          <none>
```

## Logs deployment/audit-security-service

```text
  #2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(214): Illuminate\\Routing\\Route->runCallable()
  #3 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(822): Illuminate\\Routing\\Route->run()
  #4 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Routing\\Router->{closure:Illuminate\\Routing\\Router::runRouteWithinStack():821}(Object(Illuminate\\Http\\Request))
  #5 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(50): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #6 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #7 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/VerifyCsrfToken.php(87): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(48): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #10 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #11 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(120): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #12 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest(Object(Illuminate\\Http\\Request), Object(Illuminate\\Session\\Store), Object(Closure))
  #13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #14 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(36): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #15 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #16 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(74): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #17 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #19 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(821): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #20 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(800): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))
  #21 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(764): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))
  #22 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(753): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))
  #23 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(200): Illuminate\\Routing\\Router->dispatch(Object(Illuminate\\Http\\Request))
  #24 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Foundation\\Http\\Kernel->{closure:Illuminate\\Foundation\\Http\\Kernel::dispatchToRouter():197}(Object(Illuminate\\Http\\Request))
  #25 /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php(134): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #27 /var/www/shared-security/src/Http/Middleware/SecurityHeaders.php(16): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\SecurityHeaders->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #29 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #30 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/ConvertEmptyStringsToNull.php(31): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\ConvertEmptyStringsToNull->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #32 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TrimStrings.php(51): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #34 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\TrimStrings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #35 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePostSize.php(27): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #36 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePostSize->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #37 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php(109): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #38 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\PreventRequestsDuringMaintenance->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #39 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/HandleCors.php(61): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #40 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\HandleCors->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #41 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/TrustProxies.php(58): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #42 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\TrustProxies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/InvokeDeferredCallbacks.php(22): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #44 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\InvokeDeferredCallbacks->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #45 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePathEncoding.php(26): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #46 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePathEncoding->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #47 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #48 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(175): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #49 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(144): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))
  #50 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1220): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))
  #51 /var/www/html/public/index.php(20): Illuminate\\Foundation\\Application->handleRequest(Object(Illuminate\\Http\\Request))
  #52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/resources/server.php(23): require_once('/var/www/html/p...')
  #53 {main}
  "}
  2026-07-18 13:24:56 /metrics ......................................... ~ 1s
  2026-07-18 13:24:55 /health .......................................... ~ 3s
  2026-07-18 13:25:00 /health .................................... ~ 690.56ms
  2026-07-18 13:25:11 /health .......................................... ~ 1s
  2026-07-18 13:25:15 /health .......................................... ~ 2s
  2026-07-18 13:25:21 /health .......................................... ~ 1s
  production.ERROR: Call to undefined method Prometheus\CollectorRegistry::getMetricFamilies() {"exception":"[object] (Error(code: 0): Call to undefined method Prometheus\\CollectorRegistry::getMetricFamilies() at /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php:121)
  [stacktrace]
  #0 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/CallableDispatcher.php(39): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware::{closure:SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware::registerRoutes():88}(Object(Illuminate\\Http\\Request))
  #1 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(243): Illuminate\\Routing\\CallableDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Closure))
  #2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(214): Illuminate\\Routing\\Route->runCallable()
  #3 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(822): Illuminate\\Routing\\Route->run()
  #4 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Routing\\Router->{closure:Illuminate\\Routing\\Router::runRouteWithinStack():821}(Object(Illuminate\\Http\\Request))
  #5 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(50): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #6 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #7 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/VerifyCsrfToken.php(87): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(48): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #10 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #11 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(120): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #12 /var/www/html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest(Object(Illuminate\\Http\\Request), Object(Illuminate\\Session\\Store), Object(Closure))
  #13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #14 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(36): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #15 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #16 /var/www/html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(74): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #17 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #19 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(821): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #20 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(800): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))
  #21 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(764): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))
  #22 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(753): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))
  #23 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(200): Illuminate\\Routing\\Router->dispatch(Object(Illuminate\\Http\\Request))
  #24 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Foundation\\Http\\Kernel->{closure:Illuminate\\Foundation\\Http\\Kernel::dispatchToRouter():197}(Object(Illuminate\\Http\\Request))
  #25 /var/www/shared-security/src/Http/Middleware/PrometheusMetricsMiddleware.php(134): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}(Object(Illuminate\\Http\\Request))
  #26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\PrometheusMetricsMiddleware->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #27 /var/www/shared-security/src/Http/Middleware/SecurityHeaders.php(16): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): SecureRag\\LaravelSecurity\\Http\\Middleware\\SecurityHeaders->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #29 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #30 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/ConvertEmptyStringsToNull.php(31): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\ConvertEmptyStringsToNull->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #32 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TransformsRequest.php(21): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/TrimStrings.php(51): Illuminate\\Foundation\\Http\\Middleware\\TransformsRequest->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #34 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\TrimStrings->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #35 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePostSize.php(27): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #36 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePostSize->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #37 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php(109): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #38 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\PreventRequestsDuringMaintenance->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #39 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/HandleCors.php(61): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #40 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\HandleCors->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #41 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/TrustProxies.php(58): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #42 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\TrustProxies->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/InvokeDeferredCallbacks.php(22): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #44 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Foundation\\Http\\Middleware\\InvokeDeferredCallbacks->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #45 /var/www/html/vendor/laravel/framework/src/Illuminate/Http/Middleware/ValidatePathEncoding.php(26): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #46 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(219): Illuminate\\Http\\Middleware\\ValidatePathEncoding->handle(Object(Illuminate\\Http\\Request), Object(Closure))
  #47 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:{closure:Illuminate\\Pipeline\\Pipeline::carry():194}:195}(Object(Illuminate\\Http\\Request))
  #48 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(175): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))
  #49 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(144): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))
  #50 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1220): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))
  #51 /var/www/html/public/index.php(20): Illuminate\\Foundation\\Application->handleRequest(Object(Illuminate\\Http\\Request))
  #52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/resources/server.php(23): require_once('/var/www/html/p...')
  #53 {main}
  "}
  2026-07-18 13:25:27 /metrics ......................................... ~ 1s
  2026-07-18 13:25:32 /health .......................................... ~ 2s
  2026-07-18 13:25:37 /health .......................................... ~ 1s
  2026-07-18 13:25:42 /health .......................................... ~ 2s
```

## Reading guide

- `TERMINÉ` means the runtime command succeeded in the current cluster.
- `PARTIEL` means the Kubernetes object is missing or incomplete.
- `DÉPENDANT_DE_L_ENVIRONNEMENT` means an active cluster, metrics-server or kubeconfig is required.
- This script is read-only and does not install, patch, delete or restart any workload.
