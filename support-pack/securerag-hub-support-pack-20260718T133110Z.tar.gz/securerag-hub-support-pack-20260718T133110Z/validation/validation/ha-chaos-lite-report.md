# HA Chaos Lite Report - SecureRAG Hub

- Generated at UTC: `2026-07-18T13:26:21Z`
- Namespace: `securerag-hub`
- RUN_POD_DELETE: `false`
- RUN_ROLLOUT_RESTART: `false`
- RUN_NODE_DRAIN: `false`

| Check | Status | Evidence |
|---|---:|---|
| Kubernetes API | TERMINÉ | API server reachable |
| deployment/portal-web available | PARTIEL | Deployment not Available within 30s |
| deployment/auth-users available | PARTIEL | Deployment not Available within 30s |
| deployment/chatbot-manager available | TERMINÉ | Available condition true |
| deployment/conversation-service available | TERMINÉ | Available condition true |
| deployment/audit-security-service available | TERMINÉ | Available condition true |
| PDB allowed disruptions | PARTIEL | no PDB currently allows disruption |
| Pod node spread | TERMINÉ | official pods span 3 nodes |
| Pod delete recovery | PRÊT_NON_EXÉCUTÉ | set RUN_POD_DELETE=true to delete one pod per official deployment |
| Rollout restart proof | PRÊT_NON_EXÉCUTÉ | set RUN_ROLLOUT_RESTART=true to restart official deployments |
| Node drain proof | PRÊT_NON_EXÉCUTÉ | set RUN_NODE_DRAIN=true CONFIRM_NODE_DRAIN=YES NODE_NAME=<worker> |

## Deployments

```text
NAME                     READY   UP-TO-DATE   AVAILABLE   AGE     CONTAINERS               IMAGES                                                     SELECTOR
audit-security-service   1/1     1            1           24d     audit-security-service   localhost:5001/securerag-hub-audit-security-service:demo   app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub
auth-users               1/3     1            1           7d14h   auth-users               localhost:5001/securerag-hub-auth-users:demo               app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub
chatbot-manager          1/1     1            1           24d     chatbot-manager          localhost:5001/securerag-hub-chatbot-manager:demo          app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub
conversation-service     1/1     1            1           24d     conversation-service     localhost:5001/securerag-hub-conversation-service:demo     app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub
portal-web               0/2     1            0           24d     portal-web               localhost:5001/securerag-hub-portal-web:demo               app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub
postgres-auth            1/1     1            1           24d     postgres-auth            localhost:5001/postgres:16-alpine                          app.kubernetes.io/name=postgres-auth,app.kubernetes.io/part-of=securerag-hub
```

## Pods

```text
NAME                                      READY   STATUS                       RESTARTS         AGE     IP             NODE                   NOMINATED NODE   READINESS GATES
audit-security-service-5dc8b86497-srmhp   1/1     Running                      1 (44h ago)      7d5h    10.244.0.96    securerag-dev-worker   <none>           <none>
auth-users-557c884c45-skbzz               1/1     Running                      1 (44h ago)      7d5h    10.244.0.174   securerag-dev-worker   <none>           <none>
chatbot-manager-5c868487d8-gh4sv          1/1     Running                      1 (44h ago)      7d5h    10.244.0.251   securerag-dev-worker   <none>           <none>
conversation-service-7678f59b49-fqg8b     1/1     Running                      1 (44h ago)      7d5h    10.244.0.116   securerag-dev-worker   <none>           <none>
portal-web-84bd8bb87c-fm7sj               0/1     CreateContainerConfigError   63 (9m52s ago)   7d14h   10.244.0.137   securerag-dev-worker   <none>           <none>
postgres-auth-fbf55db78-kwlh4             1/1     Running                      1 (44h ago)      23d     10.244.0.202   securerag-dev-worker   <none>           <none>
```

## PDB

```text
NAME                         MIN AVAILABLE   MAX UNAVAILABLE   ALLOWED DISRUPTIONS   AGE
audit-security-service-pdb   1               N/A               0                     24d
auth-users-pdb               1               N/A               0                     24d
chatbot-manager-pdb          1               N/A               0                     24d
conversation-service-pdb     1               N/A               0                     24d
portal-web-pdb               1               N/A               0                     24d
```

## HPA

```text
NAME         REFERENCE               TARGETS              MINPODS   MAXPODS   REPLICAS   AGE
portal-web   Deployment/portal-web   cpu: <unknown>/70%   1         3         2          24d
```

## Recent events

```text
LAST SEEN   TYPE      REASON            OBJECT                                        MESSAGE
27m         Warning   PolicyViolation   replicaset/portal-web-5c9c9c5d66              policy securerag-disallow-root-containers/autogen-check-run-as-non-root fail: validation error: Pods must run as non-root (runAsNonRoot: true). rule autogen-check-run-as-non-root failed at path /spec/template/spec/containers/0/securityContext/runAsNonRoot/
67m         Warning   Unhealthy         pod/conversation-service-7678f59b49-fqg8b     Liveness probe failed: Get "http://10.244.0.116:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
66m         Warning   Unhealthy         pod/chatbot-manager-5c868487d8-gh4sv          Liveness probe failed: Get "http://10.244.0.251:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
66m         Warning   Unhealthy         pod/audit-security-service-5dc8b86497-srmhp   Readiness probe failed: Get "http://10.244.0.96:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
65m         Normal    Pulled            pod/portal-web-84bd8bb87c-fm7sj               Successfully pulled image "localhost:5001/securerag-hub-portal-web:demo" in 1.397s (1.398s including waiting). Image size: 268260149 bytes.
65m         Warning   Failed            pod/portal-web-84bd8bb87c-fm7sj               Error: failed to sync configmap cache: timed out waiting for the condition
64m         Warning   Unhealthy         pod/auth-users-557c884c45-skbzz               Liveness probe failed: Get "http://10.244.0.174:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
56m         Normal    Killing           pod/portal-web-84bd8bb87c-fm7sj               Container portal-web failed startup probe, will be restarted
51m         Warning   Unhealthy         pod/audit-security-service-5dc8b86497-srmhp   Liveness probe failed: Get "http://10.244.0.96:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
47m         Normal    Pulled            pod/portal-web-84bd8bb87c-fm7sj               Successfully pulled image "localhost:5001/securerag-hub-portal-web:demo" in 2.797s (2.797s including waiting). Image size: 268260149 bytes.
41m         Normal    Created           pod/portal-web-84bd8bb87c-fm7sj               Created container: portal-web
36m         Warning   BackOff           pod/portal-web-84bd8bb87c-fm7sj               Back-off restarting failed container portal-web in pod portal-web-84bd8bb87c-fm7sj_securerag-hub(d11acadd-fcfb-4a6e-8ac3-2f0b40202c04)
30m         Warning   Unhealthy         pod/conversation-service-7678f59b49-fqg8b     Readiness probe failed: Get "http://10.244.0.116:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
30m         Warning   Unhealthy         pod/chatbot-manager-5c868487d8-gh4sv          Readiness probe failed: Get "http://10.244.0.251:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
30m         Normal    Started           pod/portal-web-84bd8bb87c-fm7sj               Started container portal-web
30m         Warning   Unhealthy         pod/auth-users-557c884c45-skbzz               Readiness probe failed: Get "http://10.244.0.174:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
28m         Warning   Unhealthy         pod/postgres-auth-fbf55db78-kwlh4             Liveness probe failed: command timed out: "pg_isready -U securerag -d auth_users" timed out after 3s
24m         Warning   Unhealthy         pod/portal-web-84bd8bb87c-fm7sj               Startup probe failed: Get "http://10.244.0.137:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
24m         Warning   Unhealthy         pod/postgres-auth-fbf55db78-kwlh4             Readiness probe failed: command timed out: "pg_isready -U securerag -d auth_users" timed out after 3s
23m         Normal    Pulling           pod/portal-web-84bd8bb87c-fm7sj               Pulling image "localhost:5001/securerag-hub-portal-web:demo"
```

## Safety model

- Default mode is read-only.
- Pod delete and rollout restart are mutative but bounded to official Laravel deployments.
- Node drain is guarded by `CONFIRM_NODE_DRAIN=YES` and explicit `NODE_NAME`.
