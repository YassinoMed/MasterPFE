# Runtime Image Rollout Proof - SecureRAG Hub

- Generated at UTC: `2026-07-18T13:26:20Z`
- Namespace: `securerag-hub`
- Registry: `localhost:5001`
- Image prefix: `securerag-hub`
- Image tag: `dev`
- Require digest deploy: `false`
- Digest record file: `artifacts/release/promotion-digests.txt`
- Deploy started at: `not provided`
- Status: `PARTIEL`

| Service | Status | Desired | Ready pods | Recent pods | Expected image/digest | Runtime image proof |
|---|---:|---:|---:|---:|---|---|
| `auth-users` | PARTIEL | 3 | 1 | not_checked | `localhost:5001/securerag-hub-auth-users:dev` | imageID/digest not proven |
| `chatbot-manager` | PARTIEL | 1 | 1 | not_checked | `localhost:5001/securerag-hub-chatbot-manager:dev` | imageID/digest not proven |
| `conversation-service` | PARTIEL | 1 | 1 | not_checked | `localhost:5001/securerag-hub-conversation-service:dev` | imageID/digest not proven |
| `audit-security-service` | PARTIEL | 1 | 1 | not_checked | `localhost:5001/securerag-hub-audit-security-service:dev` | imageID/digest not proven |
| `portal-web` | PARTIEL | 2 | 0 | not_checked | `localhost:5001/securerag-hub-portal-web:dev` | imageID/digest not proven |

## Runtime pod details

### auth-users

- Deployment images: `localhost:5001/securerag-hub-auth-users:demo`
- Deployment image ok: `False`
- Digest record ok: `True`
- `auth-users-557c884c45-skbzz` ready=`True` created=`2026-07-11T07:48:31Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-auth-users@sha256:bd41788e6601a3fae482f6fc40f6c11607be1a3a39f1ea091ebed7220134dedf`

### chatbot-manager

- Deployment images: `localhost:5001/securerag-hub-chatbot-manager:demo`
- Deployment image ok: `False`
- Digest record ok: `True`
- `chatbot-manager-5c868487d8-gh4sv` ready=`True` created=`2026-07-11T07:47:10Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-chatbot-manager@sha256:a6a7cf00fdc32e9cc75b055ed11b528373c484bda23dcbbe72655bb43ee332ea`

### conversation-service

- Deployment images: `localhost:5001/securerag-hub-conversation-service:demo`
- Deployment image ok: `False`
- Digest record ok: `True`
- `conversation-service-7678f59b49-fqg8b` ready=`True` created=`2026-07-11T07:47:10Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-conversation-service@sha256:ca1330835dbf0527e967f7b12a18d741ac956ab3e6763fb66b3b572b7d377c8a`

### audit-security-service

- Deployment images: `localhost:5001/securerag-hub-audit-security-service:demo`
- Deployment image ok: `False`
- Digest record ok: `True`
- `audit-security-service-5dc8b86497-srmhp` ready=`True` created=`2026-07-11T07:47:09Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-audit-security-service@sha256:607c582cd366596ca2fe932f46ad20d2a2e2fc5035ceb21b2d3e7ceaddc4de40`

### portal-web

- Deployment images: `localhost:5001/securerag-hub-portal-web:demo`
- Deployment image ok: `False`
- Digest record ok: `True`
- `portal-web-84bd8bb87c-fm7sj` ready=`False` created=`2026-07-10T22:54:43Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-portal-web@sha256:d3c1a466bd97669e029ffd591e28e6ac2e63ab8d039f43a1a4a61e02a9e90e91`

## Honest interpretation

- `TERMINÉ` means the deployment spec, Ready pods and runtime container image IDs match the expected tag or promoted digest.
- When `DEPLOY_STARTED_AT` is provided, pods must also be newer than the deployment action. This catches `deployment unchanged` false positives.
- Digest mode is complete only when `REQUIRE_DIGEST_DEPLOY=true` and every service has a valid promoted digest record.
