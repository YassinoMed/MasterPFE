# Production Cluster Clean Evidence - SecureRAG Hub

- Generated at UTC: `2026-07-18T12:19:53Z`
- Overlay: `infra/k8s/overlays/production`
- Namespace: `securerag-hub`
- Static-only mode: `true`

| Component | Check | Status | Evidence |
|---|---|---:|---|
| `portal-web` | official Deployment rendered | TERMINÉ | Deployment present |
| `auth-users` | official Deployment rendered | TERMINÉ | Deployment present |
| `chatbot-manager` | official Deployment rendered | TERMINÉ | Deployment present |
| `conversation-service` | official Deployment rendered | TERMINÉ | Deployment present |
| `audit-security-service` | official Deployment rendered | TERMINÉ | Deployment present |
| `api-gateway` | excluded from production render | TERMINÉ | not rendered |
| `knowledge-hub` | excluded from production render | TERMINÉ | not rendered |
| `llm-orchestrator` | excluded from production render | TERMINÉ | not rendered |
| `ollama` | excluded from production render | TERMINÉ | not rendered |
| `qdrant` | excluded from production render | TERMINÉ | not rendered |
| `security-auditor` | excluded from production render | TERMINÉ | not rendered |
| `portal-web` | official production exposure | TERMINÉ | type=NodePort, nodePort=30081 |

## Runtime

Static-only mode requested. Runtime proof is PRÊT_NON_EXÉCUTÉ.
