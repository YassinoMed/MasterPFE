# Kyverno Runtime Report - SecureRAG Hub

- Generated at UTC: `2026-07-18T13:08:56Z`
- Namespace: `securerag-hub`
- Supply chain attestation: `artifacts/release/release-attestation.json`
- Status: `PENDING`

| Component | Status | Evidence |
|---|---:|---|
