# Runtime Signature Verification — SecureRAG Hub

- Generated at UTC: `2026-07-05T11:59:20Z`
- Namespace: `securerag-hub`
- Registry: `localhost:5001`
- Cosign available: `true`
- Cluster available: `true`
- Public key: `infra/jenkins/secrets/cosign.pub`

## Verification Results

| Service | Image | Signature | Status |
|---|---|---|---|
| `portal-web` | `localhost:5001/securerag-hub-portal-web:demo` | ❌ Not verified | FAILED |
| `auth-users` | `localhost:5001/securerag-hub-auth-users:demo` | ❌ Not verified | FAILED |
| `chatbot-manager` | `localhost:5001/securerag-hub-chatbot-manager:demo` | ❌ Not verified | FAILED |
| `conversation-service` | `localhost:5001/securerag-hub-conversation-service:demo` | ❌ Not verified | FAILED |
| `audit-security-service` | `localhost:5001/securerag-hub-audit-security-service:demo` | ❌ Not verified | FAILED |

## Summary

- Verified: 0
- Failed: 5
- Skipped: 0
- **Status**: `FAILED`

## Honest interpretation

In a local kind cluster with `localhost:5001` registry, Cosign verification
In a production environment, images would be signed against a public registry
with proper TLS, making verification straightforward.
