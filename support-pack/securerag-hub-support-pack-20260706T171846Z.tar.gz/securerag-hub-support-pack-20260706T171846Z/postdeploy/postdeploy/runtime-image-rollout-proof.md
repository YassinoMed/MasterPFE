# Runtime Image Rollout Proof - SecureRAG Hub

- Generated at UTC: `2026-07-05T11:59:11Z`
- Namespace: `securerag-hub`
- Registry: `localhost:5001`
- Image prefix: `securerag-hub`
- Image tag: `dev`
- Require digest deploy: `true`
- Digest record file: `artifacts/release/promotion-digests.txt`
- Deploy started at: `not provided`
- Status: `PARTIEL`

| Service | Status | Desired | Ready pods | Recent pods | Expected image/digest | Runtime image proof |
|---|---:|---:|---:|---:|---|---|
| `auth-users` | PARTIEL | 3 | 3 | not_checked | `missing digest` | imageID/digest not proven |
| `chatbot-manager` | PARTIEL | 1 | 1 | not_checked | `missing digest` | imageID/digest not proven |
| `conversation-service` | PARTIEL | 1 | 1 | not_checked | `missing digest` | imageID/digest not proven |
| `audit-security-service` | PARTIEL | 1 | 1 | not_checked | `missing digest` | imageID/digest not proven |
| `portal-web` | PARTIEL | 3 | 3 | not_checked | `missing digest` | imageID/digest not proven |

## Runtime pod details

### auth-users

- Deployment images: `localhost:5001/securerag-hub-auth-users:demo`
- Deployment image ok: `False`
- Digest record ok: `False`
- `auth-users-8678978685-bfl4l` ready=`True` created=`2026-06-25T10:30:42Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-auth-users@sha256:7b24d8aa5f36d0db05d10fb2a46286711cc4a2304f47dde84ba796362aef5522`
- `auth-users-8678978685-l7968` ready=`True` created=`2026-06-25T10:30:54Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-auth-users@sha256:7b24d8aa5f36d0db05d10fb2a46286711cc4a2304f47dde84ba796362aef5522`
- `auth-users-8678978685-zrn25` ready=`True` created=`2026-06-25T10:31:25Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-auth-users@sha256:7b24d8aa5f36d0db05d10fb2a46286711cc4a2304f47dde84ba796362aef5522`

### chatbot-manager

- Deployment images: `localhost:5001/securerag-hub-chatbot-manager:demo`
- Deployment image ok: `False`
- Digest record ok: `False`
- `chatbot-manager-79b79d59c4-lvgtp` ready=`True` created=`2026-06-25T10:30:42Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-chatbot-manager@sha256:086ed526afb4439f6d4c5590326be3a757574ccda5e894ce1b652054bde84513`

### conversation-service

- Deployment images: `localhost:5001/securerag-hub-conversation-service:demo`
- Deployment image ok: `False`
- Digest record ok: `False`
- `conversation-service-6bc4c7dbc6-pq7xf` ready=`True` created=`2026-06-25T10:30:43Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-conversation-service@sha256:35f53f4cd274b54021812ed48b95991af875c7e8e0aa66c53bb06df65fe4e03f`

### audit-security-service

- Deployment images: `localhost:5001/securerag-hub-audit-security-service:demo`
- Deployment image ok: `False`
- Digest record ok: `False`
- `audit-security-service-667b7997b4-j5m7r` ready=`True` created=`2026-06-25T10:30:43Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-audit-security-service@sha256:6cf5cd864a1eb4b9179869b55519c1ba7b86d03f355b28506d3b7de97325d9bb`

### portal-web

- Deployment images: `localhost:5001/securerag-hub-portal-web:demo`
- Deployment image ok: `False`
- Digest record ok: `False`
- `portal-web-859c78db95-8xxmr` ready=`True` created=`2026-06-25T10:31:26Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-portal-web@sha256:fa1fc37b44b4cedc7e32c38940f1971f5e9af7c7b6d425d66d3214cd4bc18f80`
- `portal-web-859c78db95-v9vwx` ready=`True` created=`2026-06-25T10:30:59Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-portal-web@sha256:fa1fc37b44b4cedc7e32c38940f1971f5e9af7c7b6d425d66d3214cd4bc18f80`
- `portal-web-859c78db95-z68jt` ready=`True` created=`2026-06-25T10:30:42Z` recent=`None` imageIDMatch=`False`
  - imageID: `localhost:5001/securerag-hub-portal-web@sha256:fa1fc37b44b4cedc7e32c38940f1971f5e9af7c7b6d425d66d3214cd4bc18f80`

## Honest interpretation

- `TERMINÉ` means the deployment spec, Ready pods and runtime container image IDs match the expected tag or promoted digest.
- When `DEPLOY_STARTED_AT` is provided, pods must also be newer than the deployment action. This catches `deployment unchanged` false positives.
- Digest mode is complete only when `REQUIRE_DIGEST_DEPLOY=true` and every service has a valid promoted digest record.
