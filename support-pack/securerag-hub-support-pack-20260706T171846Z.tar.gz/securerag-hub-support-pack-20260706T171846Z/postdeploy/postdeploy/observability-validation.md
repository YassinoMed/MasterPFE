# Observability Validation — SecureRAG Hub

- Generated at UTC: `2026-07-05T11:59:23Z`
- Monitoring namespace: `securerag-monitoring`

## Components

| Component | Deployment | Status | Pods Ready |
|---|---|---|---|
| prometheus | ✅ Exists | Running | 1/1 |
[PASS] prometheus is running (1/1)
| grafana | ✅ Exists | Running | 1/1 |
[PASS] grafana is running (1/1)
| loki | ✅ Exists | Running | 1/1 |
[PASS] loki is running (1/1)
| alertmanager | ✅ Exists | Running | 2/2 |
[PASS] alertmanager is running (2/2)

## Services

[PASS] Service prometheus exposed on port 9090
[PASS] Service grafana exposed on port 3000
[PASS] Service loki exposed on port 3100
[PASS] Service alertmanager exposed on port 9093

## Summary

- **Status**: `OK` — all components running

## Access

```bash
# Grafana (admin / see grafana-admin Secret)
kubectl -n securerag-monitoring port-forward svc/grafana 3000:3000

# Prometheus
kubectl -n securerag-monitoring port-forward svc/prometheus 9090:9090

# Alertmanager
kubectl -n securerag-monitoring port-forward svc/alertmanager 9093:9093
```
