# Rollout Validation Report — SecureRAG Hub

- Generated at UTC: `2026-07-05T11:58:50Z`
- Namespace: `securerag-hub`
- Cluster context: `kind-securerag-dev`

## 1. Namespace
[PASS] Namespace securerag-hub exists

## 2. Deployments

| Deployment | Exists | Rollout OK | Desired | Ready | Up-to-date |
|---|---|---|---|---|---|
[PASS] Deployment portal-web rollout OK (3/3 ready)
| `portal-web` | ✅ | ✅ | 3 | 3 | 3 |
[PASS] Deployment auth-users rollout OK (3/3 ready)
| `auth-users` | ✅ | ✅ | 3 | 3 | 3 |
[PASS] Deployment chatbot-manager rollout OK (1/1 ready)
| `chatbot-manager` | ✅ | ✅ | 1 | 1 | 1 |
[PASS] Deployment conversation-service rollout OK (1/1 ready)
| `conversation-service` | ✅ | ✅ | 1 | 1 | 1 |
[PASS] Deployment audit-security-service rollout OK (1/1 ready)
| `audit-security-service` | ✅ | ✅ | 1 | 1 | 1 |

## 3. Pod Health

[PASS] No pods in CrashLoopBackOff
[PASS] No pods in ImagePullBackOff
[PASS] No pods Pending
[PASS] 10 pod(s) Running

## 4. Services and Endpoints

[PASS] Service portal-web has active endpoints
[PASS] Service auth-users has active endpoints
[PASS] Service chatbot-manager has active endpoints
[PASS] Service conversation-service has active endpoints
[PASS] Service audit-security-service has active endpoints

## 5. Recent Events (last 10)

```text
72s         Normal    Started                   pod/e2e-functional-check-1783252659         Started container e2e-functional-check-1783252659
70s         Normal    Scheduled                 pod/auditor-availability-check-1783252663   Successfully assigned securerag-hub/auditor-availability-check-1783252663 to securerag-dev-worker
70s         Normal    Pulled                    pod/auditor-availability-check-1783252663   Container image "curlimages/curl:8.11.1" already present on machine
69s         Normal    Started                   pod/auditor-availability-check-1783252663   Started container auditor-availability-check-1783252663
69s         Normal    Created                   pod/auditor-availability-check-1783252663   Created container: auditor-availability-check-1783252663
67s         Normal    Scheduled                 pod/auditor-endpoint-check-1783252663       Successfully assigned securerag-hub/auditor-endpoint-check-1783252663 to securerag-dev-worker
66s         Normal    Pulled                    pod/auditor-endpoint-check-1783252663       Container image "curlimages/curl:8.11.1" already present on machine
66s         Normal    Started                   pod/auditor-endpoint-check-1783252663       Started container auditor-endpoint-check-1783252663
66s         Normal    Created                   pod/auditor-endpoint-check-1783252663       Created container: auditor-endpoint-check-1783252663
9s          Warning   FailedGetResourceMetric   horizontalpodautoscaler/portal-web          failed to get cpu utilization: unable to get metrics for resource cpu: unable to fetch metrics from resource metrics API: the server could not find the requested resource (get pods.metrics.k8s.io)
```

## Summary

- **Status**: `OK` (0 warnings)
[PASS] Rollout validation completed: 0 failures, 0 warnings
