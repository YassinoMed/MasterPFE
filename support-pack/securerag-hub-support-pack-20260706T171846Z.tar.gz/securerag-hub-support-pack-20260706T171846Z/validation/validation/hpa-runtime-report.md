# HPA Runtime Report - SecureRAG Hub

- Generated at UTC: `2026-07-06T17:17:56Z`
- Namespace: `securerag-hub`
- Strict mode: `false`
- Status: `PARTIEL`

| Component | Check | Status | Evidence |
|---|---|---:|---|
| Kubernetes API | reachable | TERMINÉ | API server reachable |
| metrics-server | Metrics APIService Available | TERMINÉ | v1beta1.metrics.k8s.io Available |
| metrics-server | Deployment Ready | TERMINÉ | ready=1/1 |
| kubectl top | nodes | TERMINÉ | node metrics returned |
| kubectl top | pods | TERMINÉ | pod metrics returned for securerag-hub |
| `portal-web` | HPA exists | TERMINÉ | HorizontalPodAutoscaler present |
| `portal-web` | runtime metrics populated | TERMINÉ | metrics=cpu |
| `portal-web` | HPA metric condition | TERMINÉ | no failed metric condition |
| `auth-users` | HPA exists | PARTIEL | missing |
| `chatbot-manager` | HPA exists | PARTIEL | missing |
| `conversation-service` | HPA exists | PARTIEL | missing |
| `audit-security-service` | HPA exists | PARTIEL | missing |

## Kubernetes context

```text
kind-securerag-dev
```

## Metrics APIService

```text
NAME                     SERVICE                      AVAILABLE   AGE
v1beta1.metrics.k8s.io   kube-system/metrics-server   True        19h
```

## metrics-server deployment

```text
NAME             READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS       IMAGES                                                 SELECTOR
metrics-server   1/1     1            1           19h   metrics-server   registry.k8s.io/metrics-server/metrics-server:v0.8.0   k8s-app=metrics-server
```

## metrics-server pods

```text
NAME                              READY   STATUS    RESTARTS   AGE   IP            NODE                   NOMINATED NODE   READINESS GATES
metrics-server-65f5d57595-jh8q5   1/1     Running   0          19h   10.244.1.46   securerag-dev-worker   <none>           <none>
```

## Node metrics

```text
NAME                          CPU(cores)   CPU(%)   MEMORY(bytes)   MEMORY(%)   
securerag-dev-control-plane   306m         7%       1640Mi          6%          
securerag-dev-worker          290m         7%       5036Mi          20%         
```

## Pod metrics

```text
NAME                                      CPU(cores)   MEMORY(bytes)   
audit-security-service-667b7997b4-j5m7r   2m           74Mi            
auth-users-8678978685-bfl4l               5m           204Mi           
auth-users-8678978685-l7968               4m           203Mi           
auth-users-8678978685-zrn25               4m           205Mi           
chatbot-manager-79b79d59c4-lvgtp          2m           78Mi            
conversation-service-6bc4c7dbc6-pq7xf     1m           77Mi            
portal-web-859c78db95-z68jt               4m           186Mi           
postgres-auth-fbf55db78-kwlh4             9m           34Mi            
```

## HPA wide

```text
NAME         REFERENCE               TARGETS       MINPODS   MAXPODS   REPLICAS   AGE
portal-web   Deployment/portal-web   cpu: 4%/70%   1         3         3          12d
```

## HPA describe

```text
Name:                                                  portal-web
Namespace:                                             securerag-hub
Labels:                                                app.kubernetes.io/part-of=securerag-hub
Annotations:                                           kube-score/ignore:
                                                         pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
CreationTimestamp:                                     Wed, 24 Jun 2026 13:03:15 +0200
Reference:                                             Deployment/portal-web
Metrics:                                               ( current / target )
  resource cpu on pods  (as a percentage of request):  4% (4m) / 70%
Min replicas:                                          1
Max replicas:                                          3
Deployment pods:                                       3 current / 3 desired
Conditions:
  Type            Status  Reason               Message
  ----            ------  ------               -------
  AbleToScale     True    ScaleDownStabilized  recent recommendations were higher than current one, applying the highest recent recommendation
  ScalingActive   True    ValidMetricFound     the HPA was able to successfully calculate a replica count from cpu resource utilization (percentage of request)
  ScalingLimited  True    TooManyReplicas      the desired replica count is more than the maximum replica count
Events:
  Type    Reason             Age                  From                       Message
  ----    ------             ----                 ----                       -------
  Normal  SuccessfulRescale  5m46s (x6 over 19h)  horizontal-pod-autoscaler  New size: 3; reason: cpu resource utilization (percentage of request) above target
```

## Reading guide

- `TERMINÉ` means the command succeeded and runtime metrics are populated.
- `PARTIEL` means Kubernetes answered but metrics or HPA status are incomplete.
- `DÉPENDANT_DE_L_ENVIRONNEMENT` means a reachable cluster or metrics-server is required.
