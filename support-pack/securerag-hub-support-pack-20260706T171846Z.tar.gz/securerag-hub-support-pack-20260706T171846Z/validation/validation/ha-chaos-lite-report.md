# HA Chaos Lite Report - SecureRAG Hub

- Generated at UTC: `2026-07-06T17:18:36Z`
- Namespace: `securerag-hub`
- RUN_POD_DELETE: `false`
- RUN_ROLLOUT_RESTART: `false`
- RUN_NODE_DRAIN: `false`

| Check | Status | Evidence |
|---|---:|---|
| Kubernetes API | TERMINÉ | API server reachable |
| deployment/portal-web available | TERMINÉ | Available condition true |
| deployment/auth-users available | TERMINÉ | Available condition true |
| deployment/chatbot-manager available | TERMINÉ | Available condition true |
| deployment/conversation-service available | TERMINÉ | Available condition true |
| deployment/audit-security-service available | TERMINÉ | Available condition true |
| PDB allowed disruptions | TERMINÉ | at least one PDB allows safe disruption |
| Pod node spread | PARTIEL | official pods span 1 node(s) |
| Pod delete recovery | PRÊT_NON_EXÉCUTÉ | set RUN_POD_DELETE=true to delete one pod per official deployment |
| Rollout restart proof | PRÊT_NON_EXÉCUTÉ | set RUN_ROLLOUT_RESTART=true to restart official deployments |
| Node drain proof | PRÊT_NON_EXÉCUTÉ | set RUN_NODE_DRAIN=true CONFIRM_NODE_DRAIN=YES NODE_NAME=<worker> |

## Deployments

```text
NAME                     READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS               IMAGES                                                     SELECTOR
audit-security-service   1/1     1            1           12d   audit-security-service   localhost:5001/securerag-hub-audit-security-service:demo   app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub
auth-users               3/3     3            3           12d   auth-users               localhost:5001/securerag-hub-auth-users:demo               app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub
chatbot-manager          1/1     1            1           12d   chatbot-manager          localhost:5001/securerag-hub-chatbot-manager:demo          app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub
conversation-service     1/1     1            1           12d   conversation-service     localhost:5001/securerag-hub-conversation-service:demo     app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub
portal-web               1/1     1            1           12d   portal-web               localhost:5001/securerag-hub-portal-web:demo               app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub
postgres-auth            1/1     1            1           12d   postgres-auth            localhost:5001/postgres:16-alpine                          app.kubernetes.io/name=postgres-auth,app.kubernetes.io/part-of=securerag-hub
```

## Pods

```text
NAME                                      READY   STATUS    RESTARTS   AGE   IP             NODE                   NOMINATED NODE   READINESS GATES
audit-security-service-667b7997b4-j5m7r   1/1     Running   0          11d   10.244.1.226   securerag-dev-worker   <none>           <none>
auth-users-8678978685-bfl4l               1/1     Running   0          11d   10.244.1.223   securerag-dev-worker   <none>           <none>
auth-users-8678978685-l7968               1/1     Running   0          11d   10.244.1.227   securerag-dev-worker   <none>           <none>
auth-users-8678978685-zrn25               1/1     Running   0          11d   10.244.1.229   securerag-dev-worker   <none>           <none>
chatbot-manager-79b79d59c4-lvgtp          1/1     Running   0          11d   10.244.1.224   securerag-dev-worker   <none>           <none>
conversation-service-6bc4c7dbc6-pq7xf     1/1     Running   0          11d   10.244.1.225   securerag-dev-worker   <none>           <none>
portal-web-859c78db95-z68jt               1/1     Running   0          11d   10.244.1.222   securerag-dev-worker   <none>           <none>
postgres-auth-fbf55db78-kwlh4             1/1     Running   0          11d   10.244.1.212   securerag-dev-worker   <none>           <none>
```

## PDB

```text
NAME                         MIN AVAILABLE   MAX UNAVAILABLE   ALLOWED DISRUPTIONS   AGE
audit-security-service-pdb   1               N/A               0                     12d
auth-users-pdb               1               N/A               2                     12d
chatbot-manager-pdb          1               N/A               0                     12d
conversation-service-pdb     1               N/A               0                     12d
portal-web-pdb               1               N/A               0                     12d
```

## HPA

```text
NAME         REFERENCE               TARGETS       MINPODS   MAXPODS   REPLICAS   AGE
portal-web   Deployment/portal-web   cpu: 4%/70%   1         3         3          12d
```

## Recent events

```text
LAST SEEN   TYPE      REASON              OBJECT                                      MESSAGE
20m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
20m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
20m         Normal    Created             pod/k6-runner                               Created container: k6
20m         Normal    Started             pod/k6-runner                               Started container k6
19m         Normal    Killing             pod/k6-runner                               Stopping container k6
18m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
18m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
18m         Normal    Created             pod/k6-runner                               Created container: k6
18m         Normal    Started             pod/k6-runner                               Started container k6
17m         Normal    Killing             pod/k6-runner                               Stopping container k6
16m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
16m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
16m         Normal    Created             pod/k6-runner                               Created container: k6
16m         Normal    Started             pod/k6-runner                               Started container k6
15m         Normal    Killing             pod/k6-runner                               Stopping container k6
15m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
15m         Normal    Started             pod/k6-runner                               Started container k6
15m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
15m         Normal    Created             pod/k6-runner                               Created container: k6
15m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
15m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
15m         Normal    Created             pod/k6-runner                               Created container: k6
15m         Normal    Started             pod/k6-runner                               Started container k6
7m2s        Normal    Created             pod/k6-runner                               Created container: k6
7m2s        Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
7m2s        Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
7m1s        Normal    Started             pod/k6-runner                               Started container k6
6m51s       Warning   Unhealthy           pod/portal-web-859c78db95-z68jt             Readiness probe failed: Get "http://10.244.1.222:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
6m32s       Normal    SuccessfulRescale   horizontalpodautoscaler/portal-web          New size: 3; reason: cpu resource utilization (percentage of request) above target
6m31s       Normal    ScalingReplicaSet   deployment/portal-web                       Scaled up replica set portal-web-859c78db95 from 1 to 3
6m30s       Warning   Unhealthy           pod/conversation-service-6bc4c7dbc6-pq7xf   Liveness probe failed: Get "http://10.244.1.225:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
6m29s       Warning   Unhealthy           pod/conversation-service-6bc4c7dbc6-pq7xf   Readiness probe failed: Get "http://10.244.1.225:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
6m6s        Normal    Killing             pod/k6-runner                               Stopping container k6
6m6s        Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
6m6s        Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
6m6s        Normal    Created             pod/k6-runner                               Created container: k6
6m5s        Normal    Started             pod/k6-runner                               Started container k6
4m57s       Normal    Killing             pod/k6-runner                               Stopping container k6
62s         Warning   FailedCreate        replicaset/portal-web-859c78db95            Error creating: admission webhook "mutate.kyverno.svc-fail" denied the request: ...
1s          Normal    ScalingReplicaSet   deployment/portal-web                       Scaled down replica set portal-web-859c78db95 from 3 to 1
1s          Normal    SuccessfulRescale   horizontalpodautoscaler/portal-web          New size: 1; reason: All metrics below target
```

## Safety model

- Default mode is read-only.
- Pod delete and rollout restart are mutative but bounded to official Laravel deployments.
- Node drain is guarded by `CONFIRM_NODE_DRAIN=YES` and explicit `NODE_NAME`.
