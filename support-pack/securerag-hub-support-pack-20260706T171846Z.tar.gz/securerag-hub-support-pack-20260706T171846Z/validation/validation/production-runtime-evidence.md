# Production Runtime Evidence - SecureRAG Hub

- Generated at UTC: `2026-07-06T17:18:02Z`
- Namespace: `securerag-hub`
- Status: `PARTIEL`

| Component | Status | Detail |
|---|---:|---|
| Kubernetes API | TERMINÉ | API server reachable |
| Official deployments | PARTIEL | Availability check for five Laravel workloads |
| HPA objects | TERMINÉ | HPA resources returned for namespace |
| metrics-server | TERMINÉ | kubectl top works for pods and nodes |
| PodDisruptionBudget | TERMINÉ | PDB resources returned for namespace |

## Kubernetes context

```text
kind-securerag-dev
```

## Deployments

```text
NAME                     READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS               IMAGES                                                     SELECTOR
audit-security-service   1/1     1            1           12d   audit-security-service   localhost:5001/securerag-hub-audit-security-service:demo   app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub
auth-users               3/3     3            3           12d   auth-users               localhost:5001/securerag-hub-auth-users:demo               app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub
chatbot-manager          1/1     1            1           12d   chatbot-manager          localhost:5001/securerag-hub-chatbot-manager:demo          app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub
conversation-service     1/1     1            1           12d   conversation-service     localhost:5001/securerag-hub-conversation-service:demo     app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub
portal-web               1/3     1            1           12d   portal-web               localhost:5001/securerag-hub-portal-web:demo               app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub
postgres-auth            1/1     1            1           12d   postgres-auth            localhost:5001/postgres:16-alpine                          app.kubernetes.io/name=postgres-auth,app.kubernetes.io/part-of=securerag-hub
```

## Pods

```text
NAME                                      READY   STATUS    RESTARTS   AGE   IP             NODE                   NOMINATED NODE   READINESS GATES
audit-security-service-667b7997b4-j5m7r   1/1     Running   0          11d   10.244.1.226   securerag-dev-worker   <none>           <none>
auth-users-8678978685-bfl4l               1/1     Running   0          11d   10.244.1.223   securerag-dev-worker   <none>           <none>
auth-users-8678978685-l7968               1/1     Running   0          11d   10.244.1.227   securerag-dev-worker   <none>           <none>
auth-users-8678978685-zrn25               1/1     Running   0          11d   10.244.1.229   securerag-dev-worker   <none>           <none>
chatbot-manager-79b79d59c4-lvgtp          1/1     Running   0          11d   10.244.1.224   securerag-dev-worker   <none>           <none>
conversation-service-6bc4c7dbc6-pq7xf     1/1     Running   0          11d   10.244.1.225   securerag-dev-worker   <none>           <none>
portal-web-859c78db95-z68jt               1/1     Running   0          11d   10.244.1.222   securerag-dev-worker   <none>           <none>
postgres-auth-fbf55db78-kwlh4             1/1     Running   0          11d   10.244.1.212   securerag-dev-worker   <none>           <none>
```

## Services

```text
NAME                     TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)          AGE   SELECTOR
audit-security-service   ClusterIP   10.96.104.151   <none>        8000/TCP         12d   app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub
auth-users               ClusterIP   10.96.139.68    <none>        8000/TCP         12d   app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub
chatbot-manager          ClusterIP   10.96.189.113   <none>        8000/TCP         12d   app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub
conversation-service     ClusterIP   10.96.192.110   <none>        8000/TCP         12d   app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub
portal-web               NodePort    10.96.193.87    <none>        8000:30081/TCP   12d   app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub
postgres-auth            ClusterIP   10.96.110.118   <none>        5432/TCP         12d   app.kubernetes.io/name=postgres-auth,app.kubernetes.io/part-of=securerag-hub
```

## ServiceAccounts

```text
NAME                        SECRETS   AGE
default                     0         12d
sa-audit-security-service   0         12d
sa-auth-users               0         12d
sa-chatbot-manager          0         12d
sa-conversation-service     0         12d
sa-portal-web               0         12d
sa-postgres-auth            0         12d
sa-validation               0         12d
```

## Roles and RoleBindings

```text
NAME                                                        CREATED AT
role.rbac.authorization.k8s.io/securerag-runtime-readonly   2026-06-24T11:03:14Z

NAME                                                                                      ROLE                              AGE   USERS   GROUPS   SERVICEACCOUNTS
rolebinding.rbac.authorization.k8s.io/securerag-runtime-readonly-audit-security-service   Role/securerag-runtime-readonly   12d                    securerag-hub/sa-audit-security-service
```

## PDB

```text
NAME                         MIN AVAILABLE   MAX UNAVAILABLE   ALLOWED DISRUPTIONS   AGE
audit-security-service-pdb   1               N/A               0                     12d
auth-users-pdb               1               N/A               2                     12d
chatbot-manager-pdb          1               N/A               0                     12d
conversation-service-pdb     1               N/A               0                     12d
portal-web-pdb               1               N/A               0                     12d
```

## HPA

```text
NAME         REFERENCE               TARGETS       MINPODS   MAXPODS   REPLICAS   AGE
portal-web   Deployment/portal-web   cpu: 4%/70%   1         3         3          12d
```

## ResourceQuota

```text
NAME                  REQUEST                                                                                                                                                                          LIMIT                                                                                  AGE
securerag-hub-quota   persistentvolumeclaims: 0/10, pods: 8/30, requests.cpu: 1500m/6, requests.ephemeral-storage: 1152Mi/4Gi, requests.memory: 1920Mi/6Gi, requests.storage: 0/40Gi, services: 6/20   limits.cpu: 6200m/12, limits.ephemeral-storage: 4608Mi/12Gi, limits.memory: 4Gi/12Gi   12d
```

## LimitRange

```text
NAME                     CREATED AT
securerag-hub-defaults   2026-06-24T11:03:13Z
```

## NetworkPolicies

```text
NAME                             POD-SELECTOR                                                                                                    AGE
allow-dns-egress                 <none>                                                                                                          12d
allow-validation-egress          app.kubernetes.io/part-of=securerag-hub,job-role=validation                                                     12d
allow-validation-ingress         app.kubernetes.io/name in (audit-security-service,auth-users,chatbot-manager,conversation-service,portal-web)   12d
audit-security-service-network   app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub                           12d
auth-users-policy                app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub                                       12d
chatbot-manager-policy           app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub                                  12d
conversation-service-network     app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub                             12d
default-deny-all                 <none>                                                                                                          12d
portal-web-policy                app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub                                       12d
postgres-auth-policy             app.kubernetes.io/name=postgres-auth,app.kubernetes.io/part-of=securerag-hub                                    12d
```

## Pod images and imageIDs

```text
audit-security-service-667b7997b4-j5m7r	localhost:5001/securerag-hub-audit-security-service:demo	localhost:5001/securerag-hub-audit-security-service@sha256:6cf5cd864a1eb4b9179869b55519c1ba7b86d03f355b28506d3b7de97325d9bb
auth-users-8678978685-bfl4l	localhost:5001/securerag-hub-auth-users:demo	localhost:5001/securerag-hub-auth-users@sha256:7b24d8aa5f36d0db05d10fb2a46286711cc4a2304f47dde84ba796362aef5522
auth-users-8678978685-l7968	localhost:5001/securerag-hub-auth-users:demo	localhost:5001/securerag-hub-auth-users@sha256:7b24d8aa5f36d0db05d10fb2a46286711cc4a2304f47dde84ba796362aef5522
auth-users-8678978685-zrn25	localhost:5001/securerag-hub-auth-users:demo	localhost:5001/securerag-hub-auth-users@sha256:7b24d8aa5f36d0db05d10fb2a46286711cc4a2304f47dde84ba796362aef5522
chatbot-manager-79b79d59c4-lvgtp	localhost:5001/securerag-hub-chatbot-manager:demo	localhost:5001/securerag-hub-chatbot-manager@sha256:086ed526afb4439f6d4c5590326be3a757574ccda5e894ce1b652054bde84513
conversation-service-6bc4c7dbc6-pq7xf	localhost:5001/securerag-hub-conversation-service:demo	localhost:5001/securerag-hub-conversation-service@sha256:35f53f4cd274b54021812ed48b95991af875c7e8e0aa66c53bb06df65fe4e03f
portal-web-859c78db95-z68jt	localhost:5001/securerag-hub-portal-web:demo	localhost:5001/securerag-hub-portal-web@sha256:fa1fc37b44b4cedc7e32c38940f1971f5e9af7c7b6d425d66d3214cd4bc18f80
postgres-auth-fbf55db78-kwlh4	docker.io/library/postgres:16-alpine	docker.io/library/postgres@sha256:e013e867e712fec275706a6c51c966f0bb0c93cfa8f51000f85a15f9865a28cb
```

## Recent events

```text
LAST SEEN   TYPE      REASON              OBJECT                                      MESSAGE
19m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
19m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
19m         Normal    Created             pod/k6-runner                               Created container: k6
19m         Normal    Started             pod/k6-runner                               Started container k6
18m         Normal    Killing             pod/k6-runner                               Stopping container k6
17m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
17m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
17m         Normal    Created             pod/k6-runner                               Created container: k6
17m         Normal    Started             pod/k6-runner                               Started container k6
16m         Normal    Killing             pod/k6-runner                               Stopping container k6
16m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
16m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
16m         Normal    Created             pod/k6-runner                               Created container: k6
16m         Normal    Started             pod/k6-runner                               Started container k6
15m         Normal    Killing             pod/k6-runner                               Stopping container k6
15m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
15m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
15m         Normal    Created             pod/k6-runner                               Created container: k6
15m         Normal    Started             pod/k6-runner                               Started container k6
15m         Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
15m         Normal    Created             pod/k6-runner                               Created container: k6
15m         Normal    Started             pod/k6-runner                               Started container k6
15m         Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
6m53s       Normal    Created             pod/k6-runner                               Created container: k6
6m53s       Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
6m53s       Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
6m52s       Normal    Started             pod/k6-runner                               Started container k6
6m42s       Warning   Unhealthy           pod/portal-web-859c78db95-z68jt             Readiness probe failed: Get "http://10.244.1.222:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
6m23s       Normal    SuccessfulRescale   horizontalpodautoscaler/portal-web          New size: 3; reason: cpu resource utilization (percentage of request) above target
6m22s       Normal    ScalingReplicaSet   deployment/portal-web                       Scaled up replica set portal-web-859c78db95 from 1 to 3
6m21s       Warning   Unhealthy           pod/conversation-service-6bc4c7dbc6-pq7xf   Liveness probe failed: Get "http://10.244.1.225:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
6m20s       Warning   Unhealthy           pod/conversation-service-6bc4c7dbc6-pq7xf   Readiness probe failed: Get "http://10.244.1.225:8000/health": context deadline exceeded (Client.Timeout exceeded while awaiting headers)
5m57s       Normal    Scheduled           pod/k6-runner                               Successfully assigned securerag-hub/k6-runner to securerag-dev-worker
5m57s       Normal    Created             pod/k6-runner                               Created container: k6
5m57s       Normal    Pulled              pod/k6-runner                               Container image "grafana/k6:0.56.0" already present on machine
5m57s       Normal    Killing             pod/k6-runner                               Stopping container k6
5m56s       Normal    Started             pod/k6-runner                               Started container k6
4m48s       Normal    Killing             pod/k6-runner                               Stopping container k6
53s         Warning   FailedCreate        replicaset/portal-web-859c78db95            Error creating: admission webhook "mutate.kyverno.svc-fail" denied the request: ...
```

## Metrics APIService

```text
NAME                     SERVICE                      AVAILABLE   AGE
v1beta1.metrics.k8s.io   kube-system/metrics-server   True        19h
```

## Node metrics

```text
NAME                          CPU(cores)   CPU(%)   MEMORY(bytes)   MEMORY(%)   
securerag-dev-control-plane   201m         5%       1643Mi          6%          
securerag-dev-worker          252m         6%       5024Mi          20%         
```

## Pod metrics

```text
NAME                                      CPU(cores)   MEMORY(bytes)   
audit-security-service-667b7997b4-j5m7r   2m           74Mi            
auth-users-8678978685-bfl4l               3m           204Mi           
auth-users-8678978685-l7968               4m           203Mi           
auth-users-8678978685-zrn25               4m           205Mi           
chatbot-manager-79b79d59c4-lvgtp          2m           78Mi            
conversation-service-6bc4c7dbc6-pq7xf     2m           77Mi            
portal-web-859c78db95-z68jt               4m           186Mi           
postgres-auth-fbf55db78-kwlh4             9m           34Mi            
```

## Describe deployment/portal-web

```text
Name:                   portal-web
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
Annotations:            deployment.kubernetes.io/revision: 20
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-portal-web:demo":"pass"}
Selector:               app.kubernetes.io/name=portal-web,app.kubernetes.io/part-of=securerag-hub
Replicas:               3 desired | 1 updated | 1 total | 1 available | 2 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  0 max unavailable, 1 max surge
Pod Template:
  Labels:           app.kubernetes.io/name=portal-web
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-06-25T12:30:42+02:00
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-portal-web
  Containers:
   portal-web:
    Image:      localhost:5001/securerag-hub-portal-web:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                400m
      ephemeral-storage:  1Gi
      memory:             512Mi
    Requests:
      cpu:                100m
      ephemeral-storage:  256Mi
      memory:             128Mi
    Liveness:             http-get http://:http/health delay=30s timeout=3s period=20s #success=1 #failure=3
    Readiness:            http-get http://:http/health delay=10s timeout=3s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      APP_ENV:                        production
      APP_DEBUG:                      false
      INTERNAL_SERVICE_SCHEME:        http
      APP_URL:                        $(INTERNAL_SERVICE_SCHEME)://portal-web:8000
      DB_CONNECTION:                  sqlite
      DB_DATABASE:                    /tmp/securerag-runtime/database/database.sqlite
      SESSION_DRIVER:                 file
      CACHE_STORE:                    file
      LOG_CHANNEL:                    stderr
      CREATE_DOTENV:                  false
      QUEUE_CONNECTION:               sync
      SECURERAG_PORTAL_BACKEND_MODE:  auto
      AUTH_USERS_BASE_URL:            $(INTERNAL_SERVICE_SCHEME)://auth-users:8000
      CHATBOT_MANAGER_BASE_URL:       $(INTERNAL_SERVICE_SCHEME)://chatbot-manager:8000
      CONVERSATION_BASE_URL:          $(INTERNAL_SERVICE_SCHEME)://conversation-service:8000
      AUDIT_SECURITY_BASE_URL:        $(INTERNAL_SERVICE_SCHEME)://audit-security-service:8000
    Mounts:
      /tmp from tmp (rw)
      /var/www/html/bootstrap/cache from app-cache (rw)
      /var/www/html/storage from app-storage (rw)
  Volumes:
   app-storage:
    Type:       EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:     
    SizeLimit:  <unset>
   app-cache:
    Type:       EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:     
    SizeLimit:  <unset>
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type             Status  Reason
  ----             ------  ------
  Progressing      True    NewReplicaSetAvailable
  Available        False   MinimumReplicasUnavailable
  ReplicaFailure   True    FailedCreate
OldReplicaSets:    portal-web-5c55fb5dcb (0/0 replicas created), portal-web-78477ccc9c (0/0 replicas created), portal-web-866b8bb877 (0/0 replicas created), portal-web-6c8ffb98f9 (0/0 replicas created), portal-web-57546c8c47 (0/0 replicas created), portal-web-8468c5c66d (0/0 replicas created), portal-web-6bb4d89c8f (0/0 replicas created), portal-web-74fb75ffd (0/0 replicas created), portal-web-6454587c5c (0/0 replicas created), portal-web-5898f9c5cd (0/0 replicas created)
NewReplicaSet:     portal-web-859c78db95 (1/3 replicas created)
Events:
  Type    Reason             Age    From                   Message
  ----    ------             ----   ----                   -------
  Normal  ScalingReplicaSet  6m22s  deployment-controller  Scaled up replica set portal-web-859c78db95 from 1 to 3
```

## Logs deployment/portal-web

```text
  2026-07-06 17:13:25 / ............................................ ~ 0.02ms
  2026-07-06 17:13:25 /health ...................................... ~ 0.04ms
  2026-07-06 17:13:25 /health .................................... ~ 500.94ms
  2026-07-06 17:13:25 / ............................................ ~ 2.33ms
  2026-07-06 17:13:25 / ............................................ ~ 0.08ms
  2026-07-06 17:13:25 /health ...................................... ~ 0.49ms
  2026-07-06 17:13:25 /health ...................................... ~ 0.08ms
  2026-07-06 17:13:25 /health ...................................... ~ 1.46ms
  2026-07-06 17:13:25 /health ...................................... ~ 0.06ms
  2026-07-06 17:13:25 /health ...................................... ~ 0.05ms
  2026-07-06 17:13:25 / ............................................ ~ 0.47ms
  2026-07-06 17:13:25 /health ...................................... ~ 0.05ms
  2026-07-06 17:13:25 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:26 /health ...................................... ~ 0.04ms
  2026-07-06 17:13:26 /health ...................................... ~ 0.12ms
  2026-07-06 17:13:26 /health ...................................... ~ 0.05ms
  2026-07-06 17:13:26 / ............................................ ~ 0.04ms
  2026-07-06 17:13:26 /health ...................................... ~ 0.04ms
  2026-07-06 17:13:26 / ............................................ ~ 0.38ms
  2026-07-06 17:13:26 / ............................................ ~ 0.03ms
  2026-07-06 17:13:26 / ............................................ ~ 0.04ms
  2026-07-06 17:13:26 /health ...................................... ~ 0.04ms
  2026-07-06 17:13:26 / ............................................ ~ 0.10ms
  2026-07-06 17:13:26 / ............................................ ~ 0.09ms
  2026-07-06 17:13:26 / ............................................ ~ 1.53ms
  2026-07-06 17:13:26 / ............................................ ~ 0.08ms
  2026-07-06 17:13:26 / ............................................ ~ 0.25ms
  2026-07-06 17:13:26 / ............................................ ~ 0.18ms
  2026-07-06 17:13:26 / ............................................ ~ 0.08ms
  2026-07-06 17:13:26 /health ...................................... ~ 0.11ms
  2026-07-06 17:13:26 / ............................................ ~ 0.71ms
  2026-07-06 17:13:26 / ............................................ ~ 0.08ms
  2026-07-06 17:13:26 /health ...................................... ~ 0.03ms
  2026-07-06 17:13:27 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:27 / ............................................ ~ 0.34ms
  2026-07-06 17:13:27 /health ...................................... ~ 0.18ms
  2026-07-06 17:13:27 / ............................................ ~ 0.11ms
  2026-07-06 17:13:27 /health ...................................... ~ 0.37ms
  2026-07-06 17:13:27 / ............................................ ~ 0.15ms
  2026-07-06 17:13:27 /health ...................................... ~ 0.06ms
  2026-07-06 17:13:27 / ............................................ ~ 0.55ms
  2026-07-06 17:13:27 / ............................................ ~ 0.27ms
  2026-07-06 17:13:27 / ............................................ ~ 0.80ms
  2026-07-06 17:13:27 / ............................................ ~ 0.07ms
  2026-07-06 17:13:28 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:28 /health ...................................... ~ 0.11ms
  2026-07-06 17:13:28 /health ...................................... ~ 0.06ms
  2026-07-06 17:13:28 / ............................................ ~ 0.09ms
  2026-07-06 17:13:28 / ............................................ ~ 0.65ms
  2026-07-06 17:13:28 /health ...................................... ~ 1.01ms
  2026-07-06 17:13:28 /health ...................................... ~ 0.04ms
  2026-07-06 17:13:28 /health ...................................... ~ 0.14ms
  2026-07-06 17:13:28 /health ...................................... ~ 0.19ms
  2026-07-06 17:13:28 /health ...................................... ~ 0.04ms
  2026-07-06 17:13:29 /health ...................................... ~ 0.03ms
  2026-07-06 17:13:29 /health .................................... ~ 501.39ms
  2026-07-06 17:13:29 /health ...................................... ~ 0.09ms
  2026-07-06 17:13:29 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:29 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:29 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:29 /health ...................................... ~ 0.07ms
  2026-07-06 17:13:29 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:30 /health ...................................... ~ 0.08ms
  2026-07-06 17:13:30 /health ...................................... ~ 0.15ms
  2026-07-06 17:13:30 /health ...................................... ~ 0.85ms
  2026-07-06 17:13:30 /health ...................................... ~ 0.10ms
  2026-07-06 17:13:30 /health ...................................... ~ 0.03ms
  2026-07-06 17:13:30 /health ...................................... ~ 0.13ms
  2026-07-06 17:13:30 /health ...................................... ~ 0.09ms
  2026-07-06 17:13:31 /health ...................................... ~ 0.22ms
  2026-07-06 17:13:31 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:31 /health ...................................... ~ 1.04ms
  2026-07-06 17:13:32 /health ...................................... ~ 0.14ms
  2026-07-06 17:13:32 /health ...................................... ~ 0.06ms
  2026-07-06 17:13:33 /health ...................................... ~ 0.79ms
  2026-07-06 17:13:39 /health ...................................... ~ 0.11ms
  2026-07-06 17:13:43 /health ...................................... ~ 0.07ms
  2026-07-06 17:13:49 /health ...................................... ~ 0.09ms
  2026-07-06 17:13:59 /health ...................................... ~ 0.14ms
  2026-07-06 17:14:03 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:09 /health ...................................... ~ 0.12ms
  2026-07-06 17:14:19 /health ...................................... ~ 0.11ms
  2026-07-06 17:14:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:29 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:39 /health ...................................... ~ 0.07ms
  2026-07-06 17:14:43 /health ...................................... ~ 0.40ms
  2026-07-06 17:14:49 /health .................................... ~ 500.26ms
  2026-07-06 17:14:59 /health .................................... ~ 500.38ms
  2026-07-06 17:15:03 /health ...................................... ~ 0.10ms
  2026-07-06 17:15:09 /health .................................... ~ 500.36ms
  2026-07-06 17:15:19 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:23 /health ...................................... ~ 0.10ms
  2026-07-06 17:15:29 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:39 /health ...................................... ~ 0.07ms
  2026-07-06 17:15:43 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:49 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:59 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:03 /health ...................................... ~ 0.11ms
  2026-07-06 17:16:09 /health ...................................... ~ 0.10ms
  2026-07-06 17:16:19 /health ...................................... ~ 0.10ms
  2026-07-06 17:16:23 /health ...................................... ~ 0.10ms
  2026-07-06 17:16:29 /health ...................................... ~ 0.12ms
  2026-07-06 17:16:39 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:49 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:59 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:03 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:09 /health ...................................... ~ 0.28ms
  2026-07-06 17:17:19 /health ...................................... ~ 0.07ms
  2026-07-06 17:17:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:29 /health ...................................... ~ 0.11ms
  2026-07-06 17:17:39 /health ...................................... ~ 0.14ms
  2026-07-06 17:17:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:49 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:59 /health ...................................... ~ 0.09ms
  2026-07-06 17:18:03 /health ...................................... ~ 0.07ms
  2026-07-06 17:18:09 /health ...................................... ~ 0.11ms
  2026-07-06 17:18:19 /health ...................................... ~ 0.09ms
  2026-07-06 17:18:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:18:29 /health ...................................... ~ 0.10ms
```

## Describe deployment/auth-users

```text
Name:                   auth-users
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
Annotations:            deployment.kubernetes.io/revision: 23
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-auth-users:demo":"pass"}
Selector:               app.kubernetes.io/name=auth-users,app.kubernetes.io/part-of=securerag-hub
Replicas:               3 desired | 3 updated | 3 total | 3 available | 0 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:           app.kubernetes.io/name=auth-users
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-06-25T12:30:42+02:00
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-auth-users
  Containers:
   auth-users:
    Image:      localhost:5001/securerag-hub-auth-users:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                800m
      ephemeral-storage:  512Mi
      memory:             512Mi
    Requests:
      cpu:                200m
      ephemeral-storage:  128Mi
      memory:             256Mi
    Liveness:             http-get http://:http/health delay=15s timeout=10s period=20s #success=1 #failure=6
    Readiness:            http-get http://:http/health delay=5s timeout=10s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      OTEL_PHP_AUTOLOAD_ENABLED:    true
      OTEL_TRACES_EXPORTER:         otlp
      OTEL_EXPORTER_OTLP_ENDPOINT:  http://otel-collector.otel-system.svc.cluster.local:4318
      OTEL_SERVICE_NAME:            auth-users
      SERVICE_NAME:                 auth-users-service
      INTERNAL_SERVICE_SCHEME:      http
      APP_ENV:                      production
      APP_DEBUG:                    false
      APP_URL:                      $(INTERNAL_SERVICE_SCHEME)://auth-users:8000
      DB_CONNECTION:                pgsql
      DB_HOST:                      postgres-auth
      DB_PORT:                      5432
      DB_DATABASE:                  auth_users
      DB_USERNAME:                  securerag
      DB_SSLMODE:                   disable
      SESSION_DRIVER:               file
      CACHE_STORE:                  file
      QUEUE_CONNECTION:             sync
      LOG_CHANNEL:                  stderr
      CREATE_DOTENV:                false
      SECURERAG_AUTHZ_ALLOW_LOCAL:  false
    Mounts:
      /tmp from tmp (rw)
  Volumes:
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type           Status  Reason
  ----           ------  ------
  Available      True    MinimumReplicasAvailable
  Progressing    True    NewReplicaSetAvailable
OldReplicaSets:  auth-users-8547b5bfb (0/0 replicas created), auth-users-685bb744b8 (0/0 replicas created), auth-users-596cb4b6b6 (0/0 replicas created), auth-users-9886bf44b (0/0 replicas created), auth-users-dbddb9b59 (0/0 replicas created), auth-users-6876975497 (0/0 replicas created), auth-users-6d79d66cc5 (0/0 replicas created), auth-users-5ff9cd9948 (0/0 replicas created), auth-users-698f76867b (0/0 replicas created), auth-users-7f7667b546 (0/0 replicas created)
NewReplicaSet:   auth-users-8678978685 (3/3 replicas created)
Events:          <none>
```

## Logs deployment/auth-users

```text
Found 3 pods, using pod/auth-users-8678978685-bfl4l
  2026-07-06 17:13:21 /api/v1/health ............................... ~ 0.65ms
  2026-07-06 17:13:21 /api/v1/health ............................... ~ 0.10ms
  2026-07-06 17:13:20 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:22 /api/v1/health ............................... ~ 0.75ms
  2026-07-06 17:13:22 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:22 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:21 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:22 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:21 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:21 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:21 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:21 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:21 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:21 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:22 /api/v1/health ............................. ~ 502.83ms
  2026-07-06 17:13:22 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:22 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:23 /api/v1/health ............................... ~ 0.15ms
  2026-07-06 17:13:23 /health ...................................... ~ 0.81ms
  2026-07-06 17:13:23 /api/v1/health ............................... ~ 0.10ms
  2026-07-06 17:13:22 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:22 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:22 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:22 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:23 /api/v1/health ............................... ~ 0.12ms
  2026-07-06 17:13:22 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:22 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:24 /api/v1/health ............................... ~ 0.35ms
  2026-07-06 17:13:24 /api/v1/health ............................... ~ 1.99ms
  2026-07-06 17:13:23 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:24 /health ...................................... ~ 0.05ms
  2026-07-06 17:13:24 /api/v1/health ............................... ~ 0.07ms
  2026-07-06 17:13:23 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:24 /api/v1/health ............................... ~ 1.08ms
  2026-07-06 17:13:23 /api/v1/users .............................. ~ 521.19ms
  2026-07-06 17:13:23 /api/v1/users .............................. ~ 521.91ms
  2026-07-06 17:13:24 /api/v1/health ............................... ~ 0.13ms
  2026-07-06 17:13:23 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:23 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:23 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:23 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:23 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:24 /api/v1/users .............................. ~ 514.58ms
  2026-07-06 17:13:24 /api/v1/users .............................. ~ 516.67ms
  2026-07-06 17:13:24 /api/v1/users .............................. ~ 514.62ms
  2026-07-06 17:13:24 /api/v1/users .............................. ~ 513.67ms
  2026-07-06 17:13:24 /api/v1/health ............................... ~ 2.14ms
  2026-07-06 17:13:24 /api/v1/health ............................... ~ 2.47ms
  2026-07-06 17:13:24 /api/v1/users .............................. ~ 516.33ms
  2026-07-06 17:13:24 /api/v1/users .................................... ~ 1s
  2026-07-06 17:13:24 /api/v1/users .............................. ~ 507.59ms
  2026-07-06 17:13:24 /api/v1/users .............................. ~ 507.53ms
  2026-07-06 17:13:24 /api/v1/users .............................. ~ 507.45ms
  2026-07-06 17:13:25 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:25 /api/v1/users .............................. ~ 501.34ms
  2026-07-06 17:13:25 /api/v1/users .............................. ~ 501.91ms
  2026-07-06 17:13:25 /api/v1/health ............................... ~ 0.18ms
  2026-07-06 17:13:25 /api/v1/health ............................... ~ 0.18ms
  2026-07-06 17:13:26 /api/v1/health ............................... ~ 0.13ms
  2026-07-06 17:13:26 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:26 /api/v1/health ............................... ~ 0.05ms
  2026-07-06 17:13:26 /api/v1/users ................................ ~ 0.06ms
  2026-07-06 17:13:26 /api/v1/health ............................... ~ 0.13ms
  2026-07-06 17:13:26 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:27 /api/v1/health ............................... ~ 0.07ms
  2026-07-06 17:13:27 /api/v1/health ............................... ~ 0.07ms
  2026-07-06 17:13:27 /api/v1/health ............................... ~ 0.08ms
  2026-07-06 17:13:28 /api/v1/users ................................ ~ 0.23ms
  2026-07-06 17:13:29 /api/v1/health ............................... ~ 0.20ms
  2026-07-06 17:13:29 /api/v1/health ............................... ~ 0.09ms
  2026-07-06 17:13:29 /api/v1/health ............................... ~ 0.07ms
  2026-07-06 17:13:29 /api/v1/health ............................... ~ 0.07ms
  2026-07-06 17:13:29 /api/v1/health ............................... ~ 0.14ms
  2026-07-06 17:13:30 /api/v1/health ............................... ~ 0.14ms
  2026-07-06 17:13:34 /health ...................................... ~ 0.09ms
  2026-07-06 17:13:43 /health ...................................... ~ 0.10ms
  2026-07-06 17:13:44 /health ...................................... ~ 0.08ms
  2026-07-06 17:13:54 /health ...................................... ~ 0.15ms
  2026-07-06 17:14:03 /health ...................................... ~ 0.12ms
  2026-07-06 17:14:04 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:14 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:23 /health ...................................... ~ 0.10ms
  2026-07-06 17:14:24 /health ...................................... ~ 0.10ms
  2026-07-06 17:14:34 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:43 /health ...................................... ~ 0.07ms
  2026-07-06 17:14:44 /health ...................................... ~ 0.09ms
  2026-07-06 17:14:54 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:03 /health ...................................... ~ 0.12ms
  2026-07-06 17:15:04 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:14 /health ...................................... ~ 0.07ms
  2026-07-06 17:15:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:24 /health ...................................... ~ 0.10ms
  2026-07-06 17:15:34 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:43 /health ...................................... ~ 0.14ms
  2026-07-06 17:15:44 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:54 /health ...................................... ~ 0.07ms
  2026-07-06 17:16:03 /health ...................................... ~ 0.11ms
  2026-07-06 17:16:04 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:14 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:23 /health ...................................... ~ 0.30ms
  2026-07-06 17:16:24 /health ...................................... ~ 0.10ms
  2026-07-06 17:16:34 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:44 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:54 /health ...................................... ~ 0.12ms
  2026-07-06 17:17:03 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:04 /health ...................................... ~ 0.07ms
  2026-07-06 17:17:14 /health ...................................... ~ 0.12ms
  2026-07-06 17:17:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:24 /health ...................................... ~ 0.13ms
  2026-07-06 17:17:34 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:44 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:54 /health ...................................... ~ 0.13ms
  2026-07-06 17:18:03 /health ...................................... ~ 0.08ms
  2026-07-06 17:18:04 /health ...................................... ~ 0.09ms
  2026-07-06 17:18:14 /health ...................................... ~ 0.08ms
  2026-07-06 17:18:23 /health ...................................... ~ 0.09ms
  2026-07-06 17:18:24 /health ...................................... ~ 0.10ms
  2026-07-06 17:18:34 /health ...................................... ~ 0.15ms
```

## Describe deployment/chatbot-manager

```text
Name:                   chatbot-manager
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
Annotations:            deployment.kubernetes.io/revision: 17
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-chatbot-manager:demo":"pass"}
Selector:               app.kubernetes.io/name=chatbot-manager,app.kubernetes.io/part-of=securerag-hub
Replicas:               1 desired | 1 updated | 1 total | 1 available | 0 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:           app.kubernetes.io/name=chatbot-manager
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-06-25T12:30:42+02:00
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-chatbot-manager
  Containers:
   chatbot-manager:
    Image:      localhost:5001/securerag-hub-chatbot-manager:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                800m
      ephemeral-storage:  512Mi
      memory:             512Mi
    Requests:
      cpu:                200m
      ephemeral-storage:  128Mi
      memory:             256Mi
    Liveness:             http-get http://:http/health delay=15s timeout=10s period=20s #success=1 #failure=6
    Readiness:            http-get http://:http/health delay=5s timeout=10s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      OTEL_PHP_AUTOLOAD_ENABLED:    true
      OTEL_TRACES_EXPORTER:         otlp
      OTEL_EXPORTER_OTLP_ENDPOINT:  http://otel-collector.otel-system.svc.cluster.local:4318
      OTEL_SERVICE_NAME:            chatbot-manager
      SERVICE_NAME:                 chatbot-manager-service
      INTERNAL_SERVICE_SCHEME:      http
      AUTH_USERS_URL:               $(INTERNAL_SERVICE_SCHEME)://auth-users:8000
      APP_ENV:                      production
      APP_DEBUG:                    false
      APP_URL:                      $(INTERNAL_SERVICE_SCHEME)://chatbot-manager:8000
      DB_CONNECTION:                sqlite
      DB_DATABASE:                  /tmp/securerag-runtime/database/database.sqlite
      SESSION_DRIVER:               file
      CACHE_STORE:                  file
      QUEUE_CONNECTION:             sync
      LOG_CHANNEL:                  stderr
      CREATE_DOTENV:                false
      SECURERAG_AUTHZ_ALLOW_LOCAL:  false
    Mounts:
      /tmp from tmp (rw)
  Volumes:
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type           Status  Reason
  ----           ------  ------
  Available      True    MinimumReplicasAvailable
  Progressing    True    NewReplicaSetAvailable
OldReplicaSets:  chatbot-manager-7475b9fd9d (0/0 replicas created), chatbot-manager-5d4d486988 (0/0 replicas created), chatbot-manager-56dd8f9bb4 (0/0 replicas created), chatbot-manager-67f57c8786 (0/0 replicas created), chatbot-manager-774676768b (0/0 replicas created), chatbot-manager-794979876 (0/0 replicas created), chatbot-manager-54b9bb64f8 (0/0 replicas created), chatbot-manager-7747c5c74c (0/0 replicas created), chatbot-manager-6d6958b667 (0/0 replicas created), chatbot-manager-58d8fdb94f (0/0 replicas created)
NewReplicaSet:   chatbot-manager-79b79d59c4 (1/1 replicas created)
Events:          <none>
```

## Logs deployment/chatbot-manager

```text
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.06ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.11ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.14ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.23ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.14ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.04ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.07ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.06ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.06ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.05ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.07ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.04ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.20ms
  2026-07-06 17:13:35 /api/v1/chatbots ............................. ~ 0.20ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.05ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.06ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.27ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.07ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.04ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.11ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.04ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.04ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:36 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.05ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.05ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.08ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.05ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.30ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.22ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.22ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.08ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:37 /api/v1/chatbots ............................. ~ 0.02ms
  2026-07-06 17:13:38 /api/v1/chatbots ............................. ~ 0.08ms
  2026-07-06 17:13:38 /api/v1/chatbots ............................. ~ 0.03ms
  2026-07-06 17:13:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:13:44 /health ...................................... ~ 0.07ms
  2026-07-06 17:13:54 /health ...................................... ~ 0.12ms
  2026-07-06 17:14:03 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:04 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:14 /health ...................................... ~ 0.11ms
  2026-07-06 17:14:23 /health ...................................... ~ 0.07ms
  2026-07-06 17:14:24 /health ...................................... ~ 0.07ms
  2026-07-06 17:14:34 /health ...................................... ~ 0.07ms
  2026-07-06 17:14:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:44 /health ...................................... ~ 0.09ms
  2026-07-06 17:14:54 /health ...................................... ~ 0.11ms
  2026-07-06 17:15:03 /health ...................................... ~ 0.14ms
  2026-07-06 17:15:04 /health ...................................... ~ 0.30ms
  2026-07-06 17:15:14 /health .................................... ~ 500.33ms
  2026-07-06 17:15:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:24 /health .................................... ~ 500.40ms
  2026-07-06 17:15:34 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:43 /health ...................................... ~ 0.07ms
  2026-07-06 17:15:44 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:54 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:03 /health ...................................... ~ 0.13ms
  2026-07-06 17:16:04 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:14 /health ...................................... ~ 0.11ms
  2026-07-06 17:16:23 /health ...................................... ~ 0.10ms
  2026-07-06 17:16:24 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:34 /health ...................................... ~ 0.14ms
  2026-07-06 17:16:43 /health ...................................... ~ 0.79ms
  2026-07-06 17:16:44 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:54 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:03 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:04 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:14 /health ...................................... ~ 0.09ms
  2026-07-06 17:17:23 /health ...................................... ~ 0.09ms
  2026-07-06 17:17:24 /health ...................................... ~ 0.09ms
  2026-07-06 17:17:34 /health ...................................... ~ 0.07ms
  2026-07-06 17:17:43 /health ...................................... ~ 0.07ms
  2026-07-06 17:17:44 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:54 /health ...................................... ~ 0.07ms
  2026-07-06 17:18:03 /health ...................................... ~ 0.14ms
  2026-07-06 17:18:04 /health ...................................... ~ 0.07ms
  2026-07-06 17:18:14 /health ...................................... ~ 0.08ms
  2026-07-06 17:18:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:18:24 /health ...................................... ~ 0.08ms
  2026-07-06 17:18:34 /health ...................................... ~ 0.15ms
```

## Describe deployment/conversation-service

```text
Name:                   conversation-service
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
Annotations:            deployment.kubernetes.io/revision: 17
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-conversation-service:demo":"pass"}
Selector:               app.kubernetes.io/name=conversation-service,app.kubernetes.io/part-of=securerag-hub
Replicas:               1 desired | 1 updated | 1 total | 1 available | 0 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:           app.kubernetes.io/name=conversation-service
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-06-25T12:30:43+02:00
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-conversation-service
  Containers:
   conversation-service:
    Image:      localhost:5001/securerag-hub-conversation-service:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                800m
      ephemeral-storage:  512Mi
      memory:             512Mi
    Requests:
      cpu:                200m
      ephemeral-storage:  128Mi
      memory:             256Mi
    Liveness:             http-get http://:http/health delay=15s timeout=10s period=20s #success=1 #failure=6
    Readiness:            http-get http://:http/health delay=5s timeout=10s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      OTEL_PHP_AUTOLOAD_ENABLED:    true
      OTEL_TRACES_EXPORTER:         otlp
      OTEL_EXPORTER_OTLP_ENDPOINT:  http://otel-collector.otel-system.svc.cluster.local:4318
      OTEL_SERVICE_NAME:            conversation-service
      SERVICE_NAME:                 conversation-service
      INTERNAL_SERVICE_SCHEME:      http
      APP_ENV:                      production
      APP_DEBUG:                    false
      APP_URL:                      $(INTERNAL_SERVICE_SCHEME)://conversation-service:8000
      DB_CONNECTION:                sqlite
      DB_DATABASE:                  /tmp/securerag-runtime/database/database.sqlite
      SESSION_DRIVER:               file
      CACHE_STORE:                  file
      QUEUE_CONNECTION:             sync
      LOG_CHANNEL:                  stderr
      CREATE_DOTENV:                false
      SECURERAG_AUTHZ_ALLOW_LOCAL:  false
    Mounts:
      /tmp from tmp (rw)
  Volumes:
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type           Status  Reason
  ----           ------  ------
  Available      True    MinimumReplicasAvailable
  Progressing    True    NewReplicaSetAvailable
OldReplicaSets:  conversation-service-76b5577fd5 (0/0 replicas created), conversation-service-7798c4d9f5 (0/0 replicas created), conversation-service-74cdcf4fdc (0/0 replicas created), conversation-service-6f6bfff485 (0/0 replicas created), conversation-service-5899b48485 (0/0 replicas created), conversation-service-588cc88f95 (0/0 replicas created), conversation-service-85fbdc56b5 (0/0 replicas created), conversation-service-5ffc5d5ff6 (0/0 replicas created), conversation-service-694d9d678d (0/0 replicas created), conversation-service-55b9dcbc4 (0/0 replicas created)
NewReplicaSet:   conversation-service-6bc4c7dbc6 (1/1 replicas created)
Events:          <none>
```

## Logs deployment/conversation-service

```text
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.58ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.54ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.53ms
  2026-07-06 17:13:33 /api/v1/conversations/d18e4360-3d3c-4891-929e-63ab5c859e3e/messages  ~ 0.50ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.33ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.59ms
  2026-07-06 17:13:33 /api/v1/conversations/57d2ab0a-1705-43df-8d82-9bdfa9f000f4/messages  ~ 0.46ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.27ms
  2026-07-06 17:13:33 /api/v1/conversations/e565dc25-67ae-41a2-8026-0a688ce438cd/messages  ~ 0.44ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.16ms
  2026-07-06 17:13:33 /api/v1/conversations/4c7069ff-d0d5-4988-88f9-978f596dc25c/messages  ~ 501.07ms
  2026-07-06 17:13:33 /api/v1/health ............................. ~ 500.89ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.60ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.61ms
  2026-07-06 17:13:33 /api/v1/conversations/9df3fa58-e63f-4021-a20b-974e6204b165/messages  ~ 0.35ms
  2026-07-06 17:13:33 /api/v1/conversations/2c3554c0-5847-4bb3-8e7d-ec5bec41078d/messages  ~ 0.10ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.12ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.29ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.28ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.35ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.68ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.67ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.59ms
  2026-07-06 17:13:33 /api/v1/conversations/1d77b5d8-69c2-4246-948f-2d7623bbd088/messages  ~ 0.68ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.32ms
  2026-07-06 17:13:33 /api/v1/conversations/ff0045a8-fef9-4963-a1d4-f9687335b13b/messages  ~ 0.67ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.39ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.52ms
  2026-07-06 17:13:33 /api/v1/conversations/8b24cb76-c0c0-4bb1-8a82-aa59ba82a53e/messages  ~ 0.63ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.48ms
  2026-07-06 17:13:33 /api/v1/conversations/b9c120da-4fe4-4822-a53b-a71338811f96/messages  ~ 0.72ms
  2026-07-06 17:13:33 /api/v1/conversations/b30806f9-8b17-441f-8f46-d97ed8571fa1/messages  ~ 0.48ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.59ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.99ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.99ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.85ms
  2026-07-06 17:13:33 /api/v1/conversations/c3bd16bb-73c9-4af1-8b14-c3878bfb06de/messages  ~ 0.84ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.61ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.97ms
  2026-07-06 17:13:33 /api/v1/health .............................. ~ 15.21ms
  2026-07-06 17:13:33 /api/v1/conversations/d48fdcd7-2dee-455a-8f1f-f294eda344c2/messages  ~ 0.57ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.12ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.32ms
  2026-07-06 17:13:33 /api/v1/conversations/5afdd6ab-b5e7-4217-b242-10172ded0027/messages  ~ 0.39ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.10ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 2.44ms
  2026-07-06 17:13:33 /api/v1/conversations/9b4dd3f1-587f-40cc-8ee2-2f41504d9a6d/messages  ~ 0.24ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.08ms
  2026-07-06 17:13:33 /api/v1/conversations/d20be06a-77f3-4278-99c9-74007497cdee/messages  ~ 0.35ms
  2026-07-06 17:13:33 /api/v1/conversations/1d3789ca-c076-49f4-82f5-4f6da493e386/messages  ~ 0.12ms
  2026-07-06 17:13:33 /api/v1/conversations/9ef46ee2-84bc-4bcc-a41c-05548ed94c31/messages  ~ 0.37ms
  2026-07-06 17:13:33 /api/v1/conversations/56fe857e-7419-467f-93dd-3509aee63eb5/messages  ~ 500.61ms
  2026-07-06 17:13:33 /api/v1/health ............................. ~ 500.67ms
  2026-07-06 17:13:33 /api/v1/conversations/67ae6984-8fd1-4a3c-9db8-861d48fc85f4/messages  ~ 0.33ms
  2026-07-06 17:13:33 /api/v1/conversations ........................ ~ 0.09ms
  2026-07-06 17:13:33 /api/v1/conversations/d500300f-49c8-4284-ab1e-0a171c4459de/messages  ~ 0.26ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.13ms
  2026-07-06 17:13:33 /api/v1/conversations/f7ec25d0-38e7-488f-8ef5-46f8ccdb9697/messages  ~ 0.35ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.09ms
  2026-07-06 17:13:33 /api/v1/conversations/54983adb-1336-4568-9692-d810a3ce330b/messages  ~ 0.29ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.08ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.31ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 3.36ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.43ms
  2026-07-06 17:13:33 /api/v1/conversations/dbcbac3a-ffc4-4959-8001-5101ad6b8150/messages  ~ 0.31ms
  2026-07-06 17:13:34 /api/v1/conversations/aebad371-28ac-48bd-99b3-e9ded23d0f41/messages  ~ 0.09ms
  2026-07-06 17:13:34 /api/v1/conversations ........................ ~ 0.10ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.18ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.22ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.19ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.25ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 1.87ms
  2026-07-06 17:13:34 /health ...................................... ~ 0.05ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.08ms
  2026-07-06 17:13:34 /api/v1/conversations/3fb136f7-4341-4d33-8762-8529bfb095cd/messages  ~ 0.04ms
  2026-07-06 17:13:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:13:44 /health ...................................... ~ 0.07ms
  2026-07-06 17:13:54 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:03 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:04 /health ...................................... ~ 0.10ms
  2026-07-06 17:14:14 /health ...................................... ~ 0.11ms
  2026-07-06 17:14:23 /health ...................................... ~ 0.11ms
  2026-07-06 17:14:24 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:34 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:43 /health ...................................... ~ 0.11ms
  2026-07-06 17:14:44 /health ...................................... ~ 0.10ms
  2026-07-06 17:14:54 /health ...................................... ~ 0.07ms
  2026-07-06 17:15:03 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:04 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:14 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:23 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:24 /health ...................................... ~ 0.11ms
  2026-07-06 17:15:34 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:43 /health ...................................... ~ 0.07ms
  2026-07-06 17:15:44 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:54 /health ...................................... ~ 0.11ms
  2026-07-06 17:16:03 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:04 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:14 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:24 /health ...................................... ~ 0.07ms
  2026-07-06 17:16:34 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:44 /health ...................................... ~ 0.10ms
  2026-07-06 17:16:54 /health ...................................... ~ 0.09ms
  2026-07-06 17:17:03 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:04 /health ...................................... ~ 0.14ms
  2026-07-06 17:17:14 /health ...................................... ~ 0.09ms
  2026-07-06 17:17:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:24 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:34 /health ...................................... ~ 0.12ms
  2026-07-06 17:17:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:44 /health ...................................... ~ 0.11ms
  2026-07-06 17:17:54 /health ...................................... ~ 0.07ms
  2026-07-06 17:18:03 /health ...................................... ~ 0.09ms
  2026-07-06 17:18:04 /health ...................................... ~ 0.09ms
  2026-07-06 17:18:14 /health ...................................... ~ 0.08ms
  2026-07-06 17:18:23 /health ...................................... ~ 0.16ms
  2026-07-06 17:18:24 /health ...................................... ~ 0.08ms
  2026-07-06 17:18:34 /health ...................................... ~ 0.07ms
```

## Describe deployment/audit-security-service

```text
Name:                   audit-security-service
Namespace:              securerag-hub
CreationTimestamp:      Wed, 24 Jun 2026 13:03:15 +0200
Labels:                 app.kubernetes.io/part-of=securerag-hub
Annotations:            deployment.kubernetes.io/revision: 17
                        kube-score/ignore:
                          pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                        kyverno.io/verify-images: {"localhost:5001/securerag-hub-audit-security-service:demo":"pass"}
Selector:               app.kubernetes.io/name=audit-security-service,app.kubernetes.io/part-of=securerag-hub
Replicas:               1 desired | 1 updated | 1 total | 1 available | 0 unavailable
StrategyType:           RollingUpdate
MinReadySeconds:        0
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:           app.kubernetes.io/name=audit-security-service
                    app.kubernetes.io/part-of=securerag-hub
  Annotations:      kube-score/ignore:
                      pod-probes, container-security-context-user-group-id, deployment-replicas, networkpolicy-targets-pod, container-image-pull-policy, pod-net...
                    kubectl.kubernetes.io/restartedAt: 2026-06-25T12:30:43+02:00
                    security.securerag.dev/internal-cleartext-justification: Internal ClusterIP service calls only; egress is restricted by NetworkPolicies.
                    security.securerag.dev/internal-cleartext-scope: cluster-only-networkpolicy
  Service Account:  sa-audit-security-service
  Containers:
   audit-security-service:
    Image:      localhost:5001/securerag-hub-audit-security-service:demo
    Port:       8000/TCP (http)
    Host Port:  0/TCP (http)
    Limits:
      cpu:                800m
      ephemeral-storage:  512Mi
      memory:             512Mi
    Requests:
      cpu:                200m
      ephemeral-storage:  128Mi
      memory:             256Mi
    Liveness:             http-get http://:http/health delay=15s timeout=10s period=20s #success=1 #failure=6
    Readiness:            http-get http://:http/health delay=5s timeout=10s period=10s #success=1 #failure=6
    Startup:              http-get http://:http/health delay=5s timeout=3s period=5s #success=1 #failure=18
    Environment Variables from:
      securerag-common-config   ConfigMap  Optional: false
      securerag-common-secrets  Secret     Optional: true
    Environment:
      OTEL_PHP_AUTOLOAD_ENABLED:    true
      OTEL_TRACES_EXPORTER:         otlp
      OTEL_EXPORTER_OTLP_ENDPOINT:  http://otel-collector.otel-system.svc.cluster.local:4318
      OTEL_SERVICE_NAME:            audit-security-service
      SERVICE_NAME:                 audit-security-service
      INTERNAL_SERVICE_SCHEME:      http
      APP_ENV:                      production
      APP_DEBUG:                    false
      APP_URL:                      $(INTERNAL_SERVICE_SCHEME)://audit-security-service:8000
      DB_CONNECTION:                sqlite
      DB_DATABASE:                  /tmp/securerag-runtime/database/database.sqlite
      SESSION_DRIVER:               file
      CACHE_STORE:                  file
      QUEUE_CONNECTION:             sync
      LOG_CHANNEL:                  stderr
      CREATE_DOTENV:                false
      SECURERAG_AUTHZ_ALLOW_LOCAL:  false
    Mounts:
      /tmp from tmp (rw)
  Volumes:
   tmp:
    Type:          EmptyDir (a temporary directory that shares a pod's lifetime)
    Medium:        
    SizeLimit:     <unset>
  Node-Selectors:  <none>
  Tolerations:     <none>
Conditions:
  Type           Status  Reason
  ----           ------  ------
  Available      True    MinimumReplicasAvailable
  Progressing    True    NewReplicaSetAvailable
OldReplicaSets:  audit-security-service-86d97db989 (0/0 replicas created), audit-security-service-76777d56f5 (0/0 replicas created), audit-security-service-7b97f5476c (0/0 replicas created), audit-security-service-864b876b69 (0/0 replicas created), audit-security-service-5dbc7b5bbf (0/0 replicas created), audit-security-service-5d454744b7 (0/0 replicas created), audit-security-service-6c44bb459c (0/0 replicas created), audit-security-service-bdc97f8f6 (0/0 replicas created), audit-security-service-85976dc85b (0/0 replicas created), audit-security-service-585f5dc795 (0/0 replicas created)
NewReplicaSet:   audit-security-service-667b7997b4 (1/1 replicas created)
Events:          <none>
```

## Logs deployment/audit-security-service

```text
  2026-07-06 17:13:31 /api/v1/health ............................... ~ 0.10ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.03ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.04ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.29ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.72ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.08ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.09ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.06ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.09ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.09ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 2.18ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.07ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.07ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.10ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.10ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.11ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.03ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.03ms
  2026-07-06 17:13:32 /api/v1/health ............................. ~ 500.31ms
  2026-07-06 17:13:32 /api/v1/health ............................... ~ 0.03ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.08ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.03ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.36ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.25ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.79ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.24ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.14ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 1.44ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.06ms
  2026-07-06 17:13:33 /api/v1/health ............................. ~ 500.37ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:33 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.13ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.06ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.08ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.43ms
  2026-07-06 17:13:34 /health ...................................... ~ 0.04ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.05ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.30ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.67ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.08ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.09ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.15ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 1.53ms
  2026-07-06 17:13:34 /api/v1/health ............................. ~ 500.37ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.03ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.06ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.03ms
  2026-07-06 17:13:34 /api/v1/health ............................... ~ 0.02ms
  2026-07-06 17:13:35 /api/v1/health ............................... ~ 0.09ms
  2026-07-06 17:13:43 /health ...................................... ~ 0.09ms
  2026-07-06 17:13:44 /health ...................................... ~ 0.02ms
  2026-07-06 17:13:54 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:03 /health .................................... ~ 500.39ms
  2026-07-06 17:14:04 /health ...................................... ~ 0.03ms
  2026-07-06 17:14:14 /health ...................................... ~ 0.12ms
  2026-07-06 17:14:23 /health ...................................... ~ 0.21ms
  2026-07-06 17:14:24 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:34 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:43 /health ...................................... ~ 0.07ms
  2026-07-06 17:14:44 /health ...................................... ~ 0.08ms
  2026-07-06 17:14:54 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:03 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:04 /health ...................................... ~ 0.13ms
  2026-07-06 17:15:14 /health ...................................... ~ 0.10ms
  2026-07-06 17:15:23 /health ...................................... ~ 0.09ms
  2026-07-06 17:15:24 /health ...................................... ~ 0.10ms
  2026-07-06 17:15:34 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:43 /health ...................................... ~ 0.12ms
  2026-07-06 17:15:44 /health ...................................... ~ 0.08ms
  2026-07-06 17:15:54 /health ...................................... ~ 0.07ms
  2026-07-06 17:16:03 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:04 /health ...................................... ~ 0.07ms
  2026-07-06 17:16:14 /health ...................................... ~ 0.09ms
  2026-07-06 17:16:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:24 /health ...................................... ~ 0.11ms
  2026-07-06 17:16:34 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:16:44 /health ...................................... ~ 0.11ms
  2026-07-06 17:16:54 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:03 /health ...................................... ~ 0.09ms
  2026-07-06 17:17:04 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:14 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:23 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:24 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:34 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:43 /health ...................................... ~ 0.08ms
  2026-07-06 17:17:44 /health ...................................... ~ 0.10ms
  2026-07-06 17:17:54 /health ...................................... ~ 0.09ms
  2026-07-06 17:18:03 /health ...................................... ~ 0.07ms
  2026-07-06 17:18:04 /health ...................................... ~ 0.07ms
  2026-07-06 17:18:14 /health ...................................... ~ 0.11ms
  2026-07-06 17:18:23 /health ...................................... ~ 0.14ms
  2026-07-06 17:18:24 /health ...................................... ~ 0.14ms
  2026-07-06 17:18:34 /health ...................................... ~ 0.10ms
```

## Reading guide

- `TERMINÉ` means the runtime command succeeded in the current cluster.
- `PARTIEL` means the Kubernetes object is missing or incomplete.
- `DÉPENDANT_DE_L_ENVIRONNEMENT` means an active cluster, metrics-server or kubeconfig is required.
- This script is read-only and does not install, patch, delete or restart any workload.
