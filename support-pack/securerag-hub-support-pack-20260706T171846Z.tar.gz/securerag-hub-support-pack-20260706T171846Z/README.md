# SecureRAG Hub Evidence & Support Pack

- Generated at UTC: `2026-07-06T17:18:47Z`
- Support Pack ID: `securerag-hub-support-pack-20260706T171846Z`
- Git Commit: `1f278099380ee60134cd936f2b9669f15272875e`
- Cluster Context: `kind-securerag-dev`

## Contents

- `postdeploy/`: Reports from smoke tests, k8s hardening check, and runtime checks.
- `security-artifacts/`: Trivy, Semgrep, and Gitleaks reports if generated.
- `sbom/`: CycloneDX SBOM files.
- `release/`: Release attestations and promoted digest records.
- `config/`: Pipeline files, Makefiles, and security scanning configurations.
- `k8s-runtime/`: Live cluster configurations, pods list, events, and Kyverno policy reports.
